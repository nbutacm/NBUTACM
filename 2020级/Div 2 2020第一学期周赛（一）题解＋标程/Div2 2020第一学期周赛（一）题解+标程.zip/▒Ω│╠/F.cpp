#include<iostream>
#include<cmath>

using namespace std;

char direction[20];

int main(){

    int line;
    cin >> line;

    while(line--){

        int amount;
        cin >> amount;

        int x = 0, y = 0, z = 0;
        int head = 2, face = 0, right = 1; // �ʼ�����ķ���

        for( int i = 0 ; i < amount; i++ ){

            int steps;
            cin >> direction >> steps;
            
            // ������������ǰ��ǡ���෴����ֻ��֪���������򼴿ɡ�

            if( direction[0] == 'r'){ // right

                int temp = right;
                right = (face + 3) % 6;
                face = temp;

            } else if ( direction[0] == 'l' ){ // left

                int temp =right;
                right = face;
                face = (temp +3) % 6;

            } else if ( direction[0] == 'u' ){ // up

                int temp = face;
                face = head;
                head = (temp + 3) % 6;

            } else if ( direction[0] == 'd' ){ // down

                int temp = face;
                face = ( head + 3) % 6;
                head = temp;

            } else if( direction[0] == 'b' ){ // back

                face = (face + 3) % 6;
                right = (right + 3) % 6;
            }

            switch (face) {
                case 0: x += steps; break;
                case 1: y += steps; break;
                case 2: z += steps; break;
                case 3: x -= steps; break;
                case 4: y -= steps; break;
                case 5: z -= steps; break;
            }

        }

        cout << x << " " << y << " " << z << " " << face << endl;
    }

    return 0;

}
