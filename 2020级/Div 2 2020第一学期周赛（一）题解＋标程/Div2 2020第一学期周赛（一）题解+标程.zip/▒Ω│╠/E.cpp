#include<bits/stdc++.h>
using namespace std;
typedef long long ll;
int main(){
    int t;
    ll l, r, m, i;
    cin >> t;
    while(t--){
        cin >> l >> r >> m;
        for (ll i = l; i <= r;i++){
            if(m % i <= r - l &&m / i > 0){
                cout << i << ' ' << l + m % i << ' ' << l << endl;
                break;
            }
            if(i - m % i <= r - l){
                cout << i << ' ' << l << ' ' << l + i - m % i << endl;
                break;
            }
        }
        if(i == r + 1)
            cout << endl;
    }
    return 0;
}