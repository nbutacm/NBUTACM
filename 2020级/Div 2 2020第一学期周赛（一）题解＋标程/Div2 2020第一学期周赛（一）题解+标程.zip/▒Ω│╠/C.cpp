#include<iostream>
#include<cstdio>
using namespace std;

int t,n,f[99];

int main(){
   f[0]=1,f[1]=1;
   scanf("%d",&t);
   
   while(t--){
       scanf("%d",&n);
       for(int i=2;i<=n;i++)f[i]=f[i-1]+f[i-2];
       printf("%d\n",f[n]);
   } 
    return 0;
}
