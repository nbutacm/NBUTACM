#include<iostream>
using namespace std;
typedef long long ll;
int main()
{
	int T;
	scanf("%d",&T);
	while(T--)
	{
		ll a;
		scanf("%lld",&a);
		printf("%lld\n",(a+1)/2+1); 
	} 
	return 0;
} 
