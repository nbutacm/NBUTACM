#include<bits/stdc++.h>
using namespace std;
int main(){
    string str;			
    while(getline(cin, str)){
    	int flag=1; 
    	int len=str.length();
        for(int i=0;i<len;i++){
        	if(flag){
        		if(str[i]>='a'&&str[i]<='z')
        			str[i]=str[i]-('a'-'A');
        		flag=0;
			}
			if(str[i]==' ') flag=1;
		}
		cout<<str<<endl;;
    }
    return 0;
}
