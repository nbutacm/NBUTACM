#include<bits/stdc++.h>
using namespace std;
int sum[100005];
int d[100005];
int main(){
    int n;
    while(scanf("%d",&n)!=EOF&&n){
        int a, b;
        memset(sum, 0, sizeof(sum));
        memset(d, 0, sizeof(d));
        for (int i = 1; i <= n;i++){
            scanf("%d%d", &a, &b);
            d[a]++;
            d[b + 1]--;
        }
        for (int i = 1; i <= n;i++){
            sum[i] = sum[i - 1] + d[i];
        }
        for (int i = 1; i <= n;i++){
            printf("%d", sum[i]);
            if(i!=n)
                printf(" ");
        }
        printf("\n");
    }
    return 0;
}