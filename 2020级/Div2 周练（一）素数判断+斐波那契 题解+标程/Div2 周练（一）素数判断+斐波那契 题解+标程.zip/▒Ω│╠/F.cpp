#include<iostream>
using namespace std;

int main()
{
	int T;
	cin>>T;
	while(T--)
	{
		int n,q,l;
		int a[110];
		cin>>n;
		for(int i=1;i<=n;i++)cin>>a[i];
		for(int j=1;j<=n;j++)
		{if(j%2!=0&&j!=n)
		 cout<<-a[j+1]<<' ';
		 else if(j%2==0&&j!=n)
		 cout<<a[j-1]<<' ' ;
		 else if(j%2!=0&&j==n)
		 cout<<-a[j+1]<<endl;
		 else if(j%2==0&&j==n)
		 cout<<a[j-1]<<endl;
		}
		
	}
	return 0;
 } 
