#include<iostream>
int main()
{
	int T;
		scanf("%d",&T);
	while(T--)
	{
		int n,q,t;
		int sum=0;
			scanf("%d%d",&n,&q);
		for(int i=0;i<n;i++)
		{
			scanf("%d",&t);
			sum=sum+t;
		}
		if(sum==q)
			printf("YES\n");
		else
			printf("NO\n");
	}
	return 0;
 } 
