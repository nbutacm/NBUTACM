#include<iostream>
using namespace std;

int a,b,n;

int main()
{
    int T;
    cin>>T;
    while(T--){
        cin>>a>>b>>n;
        int ans=0;
        switch(n%3){
            case 0:ans=a;break;
            case 1:ans=b;break;
            case 2:ans=a^b;break;
        }
        cout<<ans<<endl;
    }
    return 0;
}
