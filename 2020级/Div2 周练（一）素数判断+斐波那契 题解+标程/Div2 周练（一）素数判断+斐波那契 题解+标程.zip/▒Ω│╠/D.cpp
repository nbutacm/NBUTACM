#include<iostream>
#include<cstdio>
#include<cmath>
#include<algorithm>
using namespace std;
int main()
{
    int n;
    int T;
    cin>>T;
    while(T--)
    {
        cin>>n;
        int flag=0;
        if(n==1) cout<<"No"<<endl;
        else
        {
            for(int i=2;i<=sqrt(n);i++)
            {
                if(n%i==0)
                {
                    cout<<"No"<<endl;
					flag=1;
					break;
                }
            }
            if(flag==0)
			{
				cout<<"Yes"<<endl;
			} 
        }
    }
    return 0;
}
