#include<stdio.h>
#include<iostream>
#include<cmath>
using namespace std;
int isprime(int n)
{
	if(n==1) return 0;
	else{
		for(int i=2;i<n;i++)
		{
			if(n%i==0)
			{
				return 0;	
			}
		}
		return 1;	
	} 
}
int main() {
	int n,m;
	int ans;
	int sum;
	while(cin>>n>>m)
	{
		if(n==0&&m==0) break;
		int p=1;
		for(int i=n;i<=m;i++)
		{
			int sum=i*i+i+41;
			p=p&&isprime(sum);
		}
		if(p==1)
			cout<<"OK"<<endl;	
		else
			cout<<"Sorry"<<endl;
	}
	return 0;
}
