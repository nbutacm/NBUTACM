#include <stdio.h>
#include <string.h>
using namespace std;
 
int main()
{
    int t;
    int c,k,g;
    char pic[100][100];
    scanf("%d",&t);
    while(t--)
    {
        scanf("%d %d %d",&c,&k,&g);
        int n,m;
        m=(2*c)+1+(2*k);
        n=(2*g)+1+(2*k);
        memset(pic,'.',sizeof(pic));
       
        for(int i=(2*k),x=0; x<(2*g)+1; x++,i++)
        {
            if(i%2==0)
            {
                for(int j=0; j<(2*c)+1; j++)
                    if(j%2==0)pic[i][j]='+';
                    else pic[i][j]='-';
            }
            else if(i%2!=0)
            {
                for(int j=0; j<(2*c)+1; j++)
                    if(j%2==0)pic[i][j]='|';
                    else pic[i][j]='.';
            }
        }
       
        for(int i=1; i<(2*k); i++)
        {
            if(i%2!=0)
            {
                for(int j=0; j<i; j++)
                    if(j%2==0)pic[i][m-1-j]='|';
                    else pic[i][m-1-j]='/';
            }
            else if(i%2==0)
            {
                for(int j=0; j<i; j++)
                    if(j%2==0)pic[i][m-1-j]='+';
                    else pic[i][m-1-j]='.';
            }
        }
        for(int x=1; x<(2*k); x++)
        {
            int i=n-1-x;
            if(x%2!=0)
            {
                for(int j=0; j<x; j++)
                    if(j%2==0)pic[i][(2*c)+1+j]='/';
                    else pic[i][(2*c)+1+j]='|';
            }
            else if(x%2==0)
            {
                for(int j=0; j<x; j++)
                    if(j%2==0)pic[i][(2*c)+1+j]='.';
                    else pic[i][(2*c)+1+j]='+';
            }
        }
       
        for(int i=(2*k); i<(n-(2*k)); i++)
        {
            if(i%2==0)
            {
                for(int j=(2*c)+1; j<m; j++)
                    if(j%2!=0)pic[i][j]='.';
                    else pic[i][j]='+';
            }
            else if(i%2!=0)
            {
                for(int j=(2*c)+1; j<m; j++)
                    if(j%2!=0)pic[i][j]='/';
                    else pic[i][j]='|';
            }
        }
       
        for(int i=0; i<(2*k); i++)
        {
            if(i%2==0)
            {
                int j=(2*k)-i;
                for(int x=0; x<(2*c)+1; x++,j++)
                    if(x%2==0)pic[i][j]='+';
                    else pic[i][j]='-';
            }
            else if(i%2!=0)
            {
                int j=(2*k)-i;
                for(int x=0; x<(2*c)+1; x++,j++)
                    if(x%2==0) pic[i][j]='/';
                    else pic[i][j]='.';
            }
        }
        
        for(int i=0; i<(2*k); i++)
            for(int j=0; j<(2*k)-i; j++)
            {
                pic[i][j]='.';
                pic[n-1-i][m-1-j]='.';
            }
        for(int i=0; i<n; i++)
        {
            for(int j=0; j<m; j++)
                printf("%c",pic[i][j]);
            printf("\n");
        }
    }
 
    return 0;
}
