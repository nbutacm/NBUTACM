#include<iostream>
#include<algorithm>
#include<cstring>

using namespace std;

int matrix[1010][1010];

int main(){

    int line;
    scanf("%d", &line);

    while(line--){
        int n, m, x, y;
        scanf("%d %d %d %d", &m, &n, &x, &y);

        memset(matrix, 0, sizeof(matrix));

        for(int i = 1 ; i <= m ; i++){
            for(int j = 1 ;j <= n ; j++){

                int temp;
                scanf("%d",&temp);
                matrix[i][j]=matrix[i][j-1]+matrix[i-1][j]-matrix[i-1][j-1]+temp;
            }
        }

        int ans=0;

        for( int i = x ; i <= m ; i++){
            for( int j = y ; j <= n ; j++){
                ans = max(ans, matrix[i][j]-matrix[i-x][j]-matrix[i][j-y]+matrix[i-x][j-y]);
            }
        }
        printf("%d\n",ans);
    }
    return 0;
}
