#include<bits/stdc++.h>
using namespace std;
char str[100005];
int main(){
    int t;
    cin >> t;
    while(t--){
        int a, b;
        scanf("%d%d", &a, &b);
        scanf("%s", str);
        int i = 0;
        int len = strlen(str);
        int sum = 0;
        while(i<len){
            if(str[i]=='1')
                break;
            i++;
        }
        if(i!=len) sum+=a;
        while(i<len){
            if(str[i]=='1'){
                while(i<len&&str[i]=='1')
                    i++;
                if(i==len)
                    break;
            }
            else{
                int sum0 = 0;
                while(str[i]=='0'&&i<len){
                    sum0++;
                    i++;
                }
                if(i==len)
                    break;
                if(sum0*b>=a)
                    sum += a;
                else
                    sum += b*sum0;
            }
        }
        printf("%d\n", sum);
    }
    return 0;
}
