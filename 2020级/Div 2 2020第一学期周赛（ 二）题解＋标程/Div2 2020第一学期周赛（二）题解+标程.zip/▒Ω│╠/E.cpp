#include <iostream>
using namespace std;
int main()
{
	long long n,m[233],ans=0;
	cin>>n;
			for(int i=1;i<=n;i++)
			{
				cin>>m[i];
			}
			for(int j=1;j<=n;j++)
			{
				ans=ans+m[j]*j;
				if(j!=n)
				{
					ans=ans-j;
				}
			}
			
			cout<<ans<<endl;
		return 0;
}
