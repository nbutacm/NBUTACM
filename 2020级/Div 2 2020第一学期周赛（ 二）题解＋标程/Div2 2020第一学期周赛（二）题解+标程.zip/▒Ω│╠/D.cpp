#include<stdio.h>
int main()
{  
    int x1, x2, x3, x4, x5, x6, n, i, j; 
	int a[] = { 0,5,3,1 };  
	while (scanf("%d %d %d %d %d %d", &x1, &x2, &x3, &x4, &x5, &x6))
    {
    	n = 0;
		if (x1 + x2 + x3 + x4 + x5 + x6 == 0)
        	break;
        n += x6 + x5 + x4 + (x3 + 3) / 4; 
        i = x4 * 5 + a[x3 % 4];         
        if (x2 > i)
            n += (x2 - i + 8) / 9;
        j = n * 36 - x6 * 36 - x5 * 25 - x4 * 16 - x3 * 9 - x2 * 4;
        if (x1 > j)             
            n += (x1 - j + 35) / 36;
        printf("%d\n",n);
    }
    return 0;
}
