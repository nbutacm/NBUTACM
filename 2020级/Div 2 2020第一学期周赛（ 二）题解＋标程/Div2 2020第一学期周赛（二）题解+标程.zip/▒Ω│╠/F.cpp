#include<bits/stdc++.h>
using namespace std;
char mp[100][100];
int m;
void circle(int len,char c){
    for (int i = 1 + (m - len) / 2; i <= m - (m - len) / 2;i++){
        mp[i][1 + (m - len) / 2] = c;
        mp[1 + (m - len) / 2][i] = c;
        mp[m - (m - len) / 2][i] = c;
        mp[i][m - (m - len) / 2] = c;
    }
}
bool flag(int x,int y){
    if(x==1&&y==1||x==m&&y==m)
        return false;
    if(x==1&&y==m||x==m&&y==1)
        return false;
    return true;
}
int main(){
    int n, f = 0;
    char a, b;
    while (cin >> n >> a >> b){
        m = n;
        if(f)
            printf("\n");
        if(n == 1){
            printf("%c\n", a);
            continue;
        }
        while(n > 0){
            if ((n / 2) % 2){
                circle(n, b);
                n-=2;
            }
            else{
                circle(n, a);
                n-=2;
            }
        }
        for (int i = 1; i <= m;i++){
            for (int j = 1; j <= m;j++){
                if (flag(i, j))
                    printf("%c", mp[i][j]);
                else
                    printf(" ");
            }
            printf("\n");
        }
        f = 1;
    }
    return 0;
}