## Div2 基本输入输出练习题解

### [A - A+B for Input-Output Practice (I)](https://vjudge.net/problem/HDU-1089)

题意为给你两数 求这两数的和 注意多组输入和每组输出的换行就ok了

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int a, b;
    while(scanf("%d%d",&a,&b)!=EOF)
        printf("%d\n", a + b);
    return 0;
}
```





### [B - A+B for Input-Output Practice (II)](https://vjudge.net/problem/HDU-1090)

题意同A题 注意的是要输入固定t组的数据

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    //scanf("%d", &t); 同理
    while(t--){
        int a, b;
        scanf("%d%d", &a, &b);
        printf("%d\n", a + b);
    }
    return 0;
}
```



 

### [C - A+B for Input-Output Practice (III)](https://vjudge.net/problem/HDU-1091)

题意同A 这里注意a=0或b=0的情况也是要继续计算的，仅当两者均为0则满足退出条件

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int a, b;
    while(scanf("%d%d",&a,&b)!=EOF&&(a+b))
        printf("%d\n", a + b);
    return 0;
}
```



 

### [D - A+B for Input-Output Practice (IV)](https://vjudge.net/problem/HDU-1092)

题意为给你一组长度为n的数 让你求和 可以一边输入一边求和 

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int n, a;
    while(scanf("%d",&n)!=EOF&&n){
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
    }
    return 0;
}
```





### [E - A+B for Input-Output Practice (V)](https://vjudge.net/problem/HDU-1093)

题意和D题一样 区别就是就给你固定几组数据而已

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int t, a, n;
    cin >> t;
    //scanf("%d", &t); 同理
    while(t--){
        scanf("%d", &n);
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
    }
    return 0;
}
```





### [F - A+B for Input-Output Practice (VI)](https://vjudge.net/problem/HDU-1094)

题意同D 少了以0结尾

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int n, a;
    while(scanf("%d",&n)!=EOF){
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
    }
    return 0;
}
```





### [G - A+B for Input-Output Practice (VII)](https://vjudge.net/problem/HDU-1095)

题意同A 注意格式在每组输出后要多空一行

 ```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int a, b;
    while(scanf("%d%d",&a,&b)!=EOF)
        printf("%d\n\n", a + b);
    return 0;
}
 ```



### [H - A+B for Input-Output Practice (VIII)](https://vjudge.net/problem/HDU-1096)

题意同D 注意最后一个输出也要换行 其余数据就多空一行

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int t, a, n;
    cin >> t;
    //scanf("%d", &t); 同理
    while(t--){
        scanf("%d", &n);
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
        if(t!=0)
            printf("\n");	//就是这里的空行给了我3发PE
    }
    return 0;
}
```



### [I - Wrong Subtraction](https://vjudge.net/problem/CodeForces-977A)

题意为你有一个数n 可以进行-1 或者 /10 的操作 这里k比较小 直接while一个个操作就可以了

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int n , k;
    scanf("%d%d", &n, &k);
    while(k--){
        if(n%10==0)
            n /= 10;
        else
            n--;
    }
    printf("%d", n);
    return 0;
}
```



###  [J - 数据的交换输出](https://vjudge.net/problem/HDU-2016)

题意是要你长度为n的数组，第一个数据是不是最小的，如果不是就与 [2,n] 中最小数据进行交换 最后输出数组，注意在每组数据的最后一个不能有多余空格

```C++
#include<bits/stdc++.h>
using namespace std;
int main(){
    int n, a[205];
    while(scanf("%d",&n)!=EOF&&n){
        for (int i = 1; i <= n;i++)
            scanf("%d", &a[i]);
        int loc = 1 ,tmp;
        for (int i = 2; i <= n;i++){
            if(a[loc]>a[i])
                loc = i;
        }
        if(loc!=1){
            tmp = a[loc];
            a[loc] = a[1];
            a[1] = tmp;
        }
        for (int i = 1; i <= n;i++){
            printf("%d", a[i]);
            if(i!=n)
                printf(" ");    //注意这里的空格
        }
        printf("\n");
    }
    return 0;
}
```



### [I - Wrong Subtraction](https://vjudge.net/problem/CodeForces-977A)

题意是让你判断合法标识符 先判断第一个是不是下划线或者字母 合法就继续 不合法就输出no退出了

接着判断是不是数字字母下划线中的一种 不是也输出no直接退出 最后留下的情况就是yes的情况

```c++
#include<bits/stdc++.h>
using namespace std;
int main(){
    string str;
    int t;
    cin >> t;
    getchar();				//吸收回车
    while(t--){
        getline(cin, str);
        if(str[0]!='_'&&!(str[0]>='A'&&str[0]<='Z'||str[0]<='z'&&str[0]>='a')){
            printf("no\n");
            continue;
        }
        int len = str.length();
        int flag = 0;
        for (int i = 1; i < len;i++){
            if(str[i]=='_'||str[i]>='A'&&str[i]<='Z'||str[i]<='z'&&str[i]>='a'||str[i]>='0'&&str[i]<='9'){
                continue;
            }    
            else{
                printf("no\n");
                flag = 1;
                break;
            }
        }
        if(!flag)
            printf("yes\n");
    }
    return 0;
}
```



 

 

 

 

 