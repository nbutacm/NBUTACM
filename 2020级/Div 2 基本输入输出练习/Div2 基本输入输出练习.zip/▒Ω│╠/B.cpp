#include<bits/stdc++.h>
using namespace std;
int main(){
    int t;
    cin >> t;
    //scanf("%d", &t);
    while(t--){
        int a, b;
        scanf("%d%d", &a, &b);
        printf("%d\n", a + b);
    }
    return 0;
}
