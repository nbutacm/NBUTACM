#include<bits/stdc++.h>
using namespace std;
int main(){
    string str;
    int t;
    cin >> t;
    getchar();				
    while(t--){
        getline(cin, str);
        if(str[0]!='_'&&!(str[0]>='A'&&str[0]<='Z'||str[0]<='z'&&str[0]>='a')){
            printf("no\n");
            continue;
        }
        int len = str.length();
        int flag = 0;
        for (int i = 1; i < len;i++){
            if(str[i]=='_'||str[i]>='A'&&str[i]<='Z'||str[i]<='z'&&str[i]>='a'||str[i]>='0'&&str[i]<='9'){
                continue;
            }    
            else{
                printf("no\n");
                flag = 1;
                break;
            }
        }
        if(!flag)
            printf("yes\n");
    }
    return 0;
}
