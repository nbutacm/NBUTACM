#include<bits/stdc++.h>
using namespace std;
int main(){
    int a, b;
    while(scanf("%d%d",&a,&b)!=EOF&&(a+b))
        printf("%d\n", a + b);
    return 0;
}