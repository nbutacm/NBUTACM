#include<bits/stdc++.h>
using namespace std;
int main(){
    int n, a;
    while(scanf("%d",&n)!=EOF&&n){
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
    }
    return 0;
}