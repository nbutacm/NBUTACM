#include<bits/stdc++.h>
using namespace std;
int main(){
    int n, a[205];
    while(scanf("%d",&n)!=EOF&&n){
        for (int i = 1; i <= n;i++)
            scanf("%d", &a[i]);
        int loc = 1 ,tmp;
        for (int i = 2; i <= n;i++){
            if(a[loc]>a[i])
                loc = i;
        }
        if(loc!=1){
            tmp = a[loc];
            a[loc] = a[1];
            a[1] = tmp;
        }
        for (int i = 1; i <= n;i++){
            printf("%d", a[i]);
            if(i!=n)
                printf(" ");    
        }
        printf("\n");
    }
    return 0;
}
