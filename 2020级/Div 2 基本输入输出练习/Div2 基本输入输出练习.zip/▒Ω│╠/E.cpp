#include<bits/stdc++.h>
using namespace std;
int main(){
    int t, a, n;
    cin >> t;
    //scanf("%d", &t); 
    while(t--){
        scanf("%d", &n);
        int sum = 0;
        for (int i = 1; i <= n;i++){
            scanf("%d", &a);
            sum += a;
        }
        printf("%d\n", sum);
    }
    return 0;
}
