#include<cstdio>
#include<algorithm>
using namespace std;
long long n,f[100],a[100];
int len;
int main()
{
	f[1]=1;
	f[2]=2;
	for (int i=3;i<=87;i++)
	f[i]=f[i-1]+f[i-2];
    scanf("%lld",&n);
    for (int i=87;i>=1;i--)
    	if (n>=f[i]) a[i]=n/f[i],n%=f[i];
    for (int i=1;i<=87;i++)
    if (a[i]) len=i;
    printf("%d\n",len);
    for (int i=1;i<=len;i++)
    printf("%lld ",a[i]);
}
