#include <cstdio>
#include <cmath>
#include <algorithm>
#define MOD 1000000007
using namespace std; 

long long gcd(long long a,long long b)
{
	if (b) return gcd(b,a%b);
	return a;
}

long long ksm(long long a,long long b)
{
	if (b==1) return a;
	long long t=ksm(a,b/2);
	t*=t;
	t%=MOD;
	if (b%2) t*=a;
	return (t%MOD);
}
int main()
{
	long long a,b;
	freopen("2.in","r",stdin);
	freopen("2.out","w",stdout);
	scanf("%lld%lld",&a,&b);
	long long g=gcd(a,b);
	printf("%lld\n",ksm(g,a/g*b));
}
