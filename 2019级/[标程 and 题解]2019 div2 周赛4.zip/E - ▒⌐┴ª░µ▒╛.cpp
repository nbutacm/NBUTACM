#include <cstdio>
#include <algorithm>
#include <cstring>
using namespace std;
int n,t,ans;
char s[3005];
int main()
{
	scanf("%s",s+1);
	n=strlen(s+1);
	ans=1;
//��iΪ���ĵĻ��Ĵ�
	for (int i=1;i<=n;i++)
	{
		t=1;
		while (i-t+1>0&&i+t-1<=n&&s[i-t+1]==s[i+t-1]) t++;
		t--;
		ans=max(ans,t*2-1);
	}
//��i��i+1Ϊ���ĵĻ��Ĵ�
	for (int i=1;i<n;i++)
	if (s[i]==s[i+1])
	{
		t=1;
		while (i-t+1>0&&i+t<=n&&s[i-t+1]==s[i+t]) t++;
		t--;
		ans=max(ans,t*2);
	}
	printf("%d\n",ans);
}
