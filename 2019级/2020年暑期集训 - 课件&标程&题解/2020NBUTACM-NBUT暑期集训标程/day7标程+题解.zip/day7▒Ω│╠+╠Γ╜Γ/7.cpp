//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp[150][150],len,s[150];  //dp代表从空串转换到s2串的最少步数，s代表s1串0到i转换到s2串的最少次数
char s1[150],s2[150];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    while(~scanf("%s %s",s1+1,s2+1)){
        memset(dp,0,sizeof(dp));
        memset(s,0x3f,sizeof(s));
        s[0]=0;
        len=strlen(s1+1);
        for(int i=1;i<=len;i++) dp[i][i]=1;
        for(int i=2;i<=len;i++){
            for(int j=1;j<=len-i+1;j++){
                dp[j][i+j-1]=dp[j+1][i+j-1]+1;
                for(int k=j+1;k<=i+j-1;k++){    //因为要判断到右端点，dp的初值还是0，所以要加个=
                    if(s2[k]==s2[j]){
                        dp[j][i+j-1]=min(dp[j][i+j-1],dp[j+1][k]+dp[k+1][i+j-1]); //j+1是因为j和k相同，所以可以忽略j
                    }
                }
            }
        }
        for(int i=1;i<=len;i++){
            s[i]=dp[1][i];
            if(s1[i]==s2[i]) s[i]=s[i-1];
            else{
                for(int j=1;j<i;j++){
                    s[i]=min(s[i],s[j]+dp[j+1][i]);
                }
            }
        }
        pr(s[len]);
    }
    return 0;
}