//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp1[205][205],dp2[205][205],s[205],a[205],ma,mi;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    while(~sc(n)){
        mi=0x3f3f3f3f,ma=-0x3f3f3f3f;
        for(int i=1;i<=n;i++){
            sc(a[i]);
            a[i+n]=a[i];
        }
        memset(dp1,0,sizeof(dp1));
        memset(dp2,0x3f,sizeof(dp2));
        for(int i=1;i<=2*n;i++) {
            s[i]=s[i-1]+a[i];
            dp2[i][i]=0;
        }
        for(int i=2;i<=n;i++){
            for(int j=1;j<=2*n-i+1;j++){
                for(int k=j;k<i+j-1;k++){
                    dp1[j][i+j-1]=max(dp1[j][i+j-1],dp1[j][k]+dp1[k+1][i+j-1]+s[i+j-1]-s[j-1]);
                    dp2[j][i+j-1]=min(dp2[j][i+j-1],dp2[j][k]+dp2[k+1][i+j-1]+s[i+j-1]-s[j-1]);
                }
            }
        }
        for(int i=1;i<=n;i++){
            mi=min(mi,dp2[i][i+n-1]);
            ma=max(ma,dp1[i][i+n-1]);
        }
        printf("%lld %lld\n",mi,ma);
    }
    return 0;
}