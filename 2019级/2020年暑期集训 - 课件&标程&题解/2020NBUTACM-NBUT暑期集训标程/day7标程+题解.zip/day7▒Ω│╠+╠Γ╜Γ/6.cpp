//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=10007;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll t,n,dp[1005][1005];   //表示i-j这个区间的回文子序列的个数
char s[1005];

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(t);
    for(int k=1;k<=t;k++){
        memset(dp,0,sizeof(dp));
        scanf("%s",s+1);
        n=strlen(s+1);
        for(int i=1;i<=n;i++) dp[i][i]=1;
        for(int i=2;i<=n;i++){
            for(int j=1;j<=n-i+1;j++){   //因为只需要知道左端点和右端点就可以用小区间合并出我们需要的大区间了，所以可以省掉枚举断点的一维
                if(s[j]==s[i+j-1]) dp[j][i+j-1]=(dp[j+1][i+j-1]+dp[j][i+j-2]+1)%mod;   //左边的端点可以使右边的区间再次新增它原来数量的回文序列，右边同理，最后的1是左右端点的
                else dp[j][i+j-1]=(dp[j+1][i+j-1]+dp[j][i+j-2]-dp[j+1][i+j-2]+mod)%mod;   //有减法操作要+mod再取余
            }
        }
        printf("Case %d: %lld\n",k,dp[1][n]);
    }
    return 0;
}