//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp[maxn][maxn];
char s1[maxn],s2[maxn],c[maxn];
ll len1,len2,s=0;

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    cin>>(s1+1);
    cin>>(s2+1);
    len1=strlen(s1+1);
    len2=strlen(s2+1);
    for(int i=1;i<=len1;i++){
        for(int j=1;j<=len2;j++){
            if(s1[i]==s2[j]) dp[i][j]=max(dp[i][j],dp[i-1][j-1]+1);   //等于就从上一段区间更新
            else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);   //不等于就继承上一区间的lcs
        }
    }
    while(len1!=0 && len2!=0){
        if(s1[len1]==s2[len2]){    //等于就记录
            c[++s]=s1[len1--];
            len2--;
        }
        else{
            if(dp[len1-1][len2]<dp[len1][len2-1]) len2--;    //他的路径倒着回去一定是顺着大的路径走的
            else len1--;
        }
    }
    for(int i=s;i>=1;i--) cout<<c[i];    //倒着查找的路径，正着存的数组，所以要倒着输出
    cout<<endl;
    return 0;
}