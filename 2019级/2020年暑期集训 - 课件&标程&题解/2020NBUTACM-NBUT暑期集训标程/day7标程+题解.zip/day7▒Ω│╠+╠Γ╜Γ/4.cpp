//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll t,n,p,q,dp[15][15][15];   //表示队伍里有i个人，从前面能看见j个人，从后面看能看到k个人

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(t);
    while(t--){
        sc(n),sc(p),sc(q);
        memset(dp,0,sizeof(dp));
        dp[1][1][1]=1;
        for(int i=2;i<=n;i++){
            for(int j=1;j<=n;j++){
                for(int k=1;k<=n;k++){
                    dp[i][j][k]=dp[i-1][j][k]*(i-2)+dp[i-1][j-1][k]+dp[i-1][j][k-1];
                }    //我们从小到大的加，因为是从小到大加所以可以由这两个子状态dp[i-1][j-1][k]，dp[i-1][j][k-1]
                     //表示队首和队尾加一个人，dp[i-1][j][k]*(i-2)表示插到中间i-2个位置的方案数
            }
        }
        pr(dp[n][p][q]);
    }
    return 0;
}