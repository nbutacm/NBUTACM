//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e3+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll t,n,m,dp[maxn][maxn],a[maxn],b[maxn],sta;   //dp[i][j]表示前a的前i个，b的前j个元素，且以b[j]结尾的lcis

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(t);
    while(t--){
        sta=-0x3f3f3f3f;
        memset(dp,0,sizeof(dp));
        sc(n);
        for(int i=1;i<=n;i++) sc(a[i]);
        sc(m);
        for(int i=1;i<=m;i++) sc(b[i]);
        for(int i=1;i<=n;i++){
            for(int j=1;j<=m;j++){
                if(a[i]==b[j] && a[i]>sta){    //公共，上升
                    dp[i][j]=dp[i-1][j-1]+1;
                    sta=a[i];
                }
                else{
                    dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
                }
            }
        }
        pr(dp[n][m]);
        if(t) printf("\n");
    }
    return 0;
}

// //#pragma GCC oplmize(2)   //修改状态,优化空间
// #include <bits/stdc++.h>
// #define ll long long
// #define sc(x) scanf("%lld",&x)
// #define scs(x) scanf("%s",x)
// #define pr(x) printf("%lld\n",x)
// #define prs(x) printf("%s\n",x)
// using namespace std;
// const int maxn=1e3+5;
// const int mod=998244353;
// const double pi=acos(-1.0);
// const double eps = 1e-8;
// ll t,n,m,dp[maxn],a[maxn],b[maxn],sta,ma;   //dp[i]表示以a[i]结尾的序列与b数组的lcis

// int main()
// {
//     ios::sync_with_stdio(false);
//     cin.tie(0);
//     sc(t);
//     while(t--){
//         ma=-0x3f3f3f3f;
//         memset(dp,0,sizeof(dp));
//         sc(n);
//         for(int i=1;i<=n;i++) sc(a[i]);
//         sc(m);
//         for(int i=1;i<=m;i++) sc(b[i]);
//         for(int i=1;i<=n;i++){
//             sta=0;
//             for(int j=1;j<=m;j++){
//                 if(a[i]>b[j]) sta=max(sta,dp[j]);
//                 if(a[i]==b[j]) dp[j]=sta+1;
//             }
//         }
//         for(int i=1;i<=n;i++) ma=max(ma,dp[i]);
//         pr(ma);
//         if(t) printf("\n");
//     }
//     return 0;
// }