#include <bits/stdc++.h> 
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;

int const maxn = 10000 + 10;

struct node {
    int v, w;
    node(const int &v = 0, const int &w = 0) : 
        v(v), w(w) { }  
};
int n, m, k, t;
int vis[maxn];
vector<node> e[maxn];

bool bfs(int mid) {
    queue<int> q;
    memset(vis, 0, sizeof(vis));
    q.emplace(1);
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        if (u == t) return true;
        if (vis[u] == k) continue;
        for (auto &x : e[u]) {
            int v = x.v, w = x.w;
            if (vis[v] || w > mid) continue;
            q.emplace(v);
            vis[v] = vis[u] + 1;
        }
    }

    return false;
}

void solve(int &l ,int &r) {
    int ans = 0;
    while (l <= r) {
        int mid = (l + r) >> 1;
        if (bfs(mid)) {
            ans = mid;
            r = mid - 1;
        } else {
            l = mid + 1;
        }
    }
    cout << ans << endl;
}

int main(void) {
    FAST_IO;
    
    cin >> n >> m >> k >> t;
    int l = 0, r = 0;
    for (int i = 0; i < m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        r = max(w, r);
        e[u].emplace_back(node(v, w));
        e[v].emplace_back(node(u, w));
    }

    solve(l, r);
    
    return 0;
}
