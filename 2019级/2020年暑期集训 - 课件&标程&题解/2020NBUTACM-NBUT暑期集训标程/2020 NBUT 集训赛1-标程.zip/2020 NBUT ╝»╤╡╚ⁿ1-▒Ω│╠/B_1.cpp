#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;

int const maxn = 2e5 + 10;
int const MOD = 1e9 + 7;

ll a[maxn];

int main(void) {
    FAST_IO;
    
    int n, k;
    cin >> n >> k;
    for (int i = 1; i <= n; i++) {
        cin >> a[i];
    }
    sort(a + 1, a + 1 + n);
    ll ans = 1;
    int l = 1, r = n;
    int flag = 1;
    if (k & 1) {
        ans = ans * a[r];
        ans %= MOD;
        k--;
        r--;
        if (ans < 0) flag = -1;
    }
    while (k != 0) {
        ll x1 = a[l] * a[l + 1];
        ll x2 = a[r] * a[r - 1];
        if (x1 * flag > x2 * flag) {
            ans = ((ans % MOD) * (x1 % MOD) + MOD ) % MOD;
            l += 2;
        } else {
            ans = ((ans % MOD) * (x2 % MOD) + MOD ) % MOD;
            r -= 2;
        }
        k -= 2;
    }
    cout << (ans + MOD) % MOD << endl;

    return 0;
}
