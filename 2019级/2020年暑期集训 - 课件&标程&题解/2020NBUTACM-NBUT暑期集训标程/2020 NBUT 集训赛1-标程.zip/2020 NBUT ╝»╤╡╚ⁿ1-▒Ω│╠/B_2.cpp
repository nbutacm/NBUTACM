#include<iostream>
#include<algorithm>
using namespace std;
long long mod=1e9+7;
long long  a[300009];
long long f[10];
bool cmp(long long x,long long y) {
	return abs(x)<abs(y);
}
bool cmp1(long long x, long long y){
	return x>y;
}
int main() {

	long long n,m;
	cin>>n>>m;
	for(long long i=1; i<=n; i++) {
		cin>>a[i];
		if(a[i]>=0) f[1]++;
		else f[2]++;
	}
	long long l=1,r=n;
	long long  ans=1;
	if(!f[1]&&m%2==1) {
		sort(a+1,a+1+n,cmp);
		for(long long i=1; i<=m; i++) {
			ans=a[i]*ans%mod;
		}
	} else {
		sort(a+1,a+1+n,cmp1);
		while(m>0) {
			if(m%2) ans=ans*a[l]%mod,l++,m--;
			else if(m>=2) {
				if(a[l]*a[l+1]>=a[r]*a[r-1]) {
					ans=ans*a[l]%mod*a[l+1]%mod;
					l+=2;
					m-=2;
				} else {
					ans=ans*a[r-1]%mod*a[r]%mod;
					r-=2;
					m-=2;
				}
			}
		}
	}
	cout<<(ans%mod+mod)%mod<<endl;
	return 0;
}

