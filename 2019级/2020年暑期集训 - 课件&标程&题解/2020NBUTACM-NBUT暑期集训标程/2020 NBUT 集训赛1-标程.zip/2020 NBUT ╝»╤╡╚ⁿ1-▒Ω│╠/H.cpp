#include <bits/stdc++.h>

using namespace std;

int main(void) {
	int t;
	cin >> t;
	while (t--) {
		int n;
		cin >> n;
		cout << (1 ^ n) << endl;
	}
	return 0;
}
