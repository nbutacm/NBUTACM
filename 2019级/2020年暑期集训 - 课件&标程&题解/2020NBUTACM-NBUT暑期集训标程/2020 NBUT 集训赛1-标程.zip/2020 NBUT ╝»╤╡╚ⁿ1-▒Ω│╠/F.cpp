#include <bits/stdc++.h> 
#define ll long long
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
int n,ans;
string s[105],ss[105]; 
int main() 
{
	FAST_IO;
	cin>>n;
	ans=0x3f3f3f;
	for(int i=1;i<=n;i++){
		cin>>s[i];
		ss[i]=s[i]+s[i];
	}
	int f=1;
	for (int i=1;i<=n;i++) {
		int tmpsum=0;
		for (int j=1;j<=n;j++) {
			int tmp=ss[j].find(s[i]);
			if (tmp==-1) f = 0;
			else tmpsum+=tmp; 
		}
		ans=min(ans,tmpsum);
	}
	if(f==0)cout<<-1<<endl;
	else cout<<ans<<endl;
	return 0;
}
