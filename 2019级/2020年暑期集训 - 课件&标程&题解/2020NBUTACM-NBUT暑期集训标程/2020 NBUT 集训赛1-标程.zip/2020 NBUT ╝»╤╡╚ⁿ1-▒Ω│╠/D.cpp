#include<iostream>
#include<cstring>
#include<string>
#include<cmath>
#include<algorithm>
#include<map>
#include<queue>
#include<iomanip>
using namespace std;
#define ll long long
double const PI = acos(-1.0);
ll t, n;

int main()
{
	cin >> t;
	while(t--)
	{
		cin >> n;
		double tmp = 2.0 * PI / 8.0 / n;
		cout << setprecision(9) << fixed << 0.5/sin(tmp) << endl;
	}
	return 0;
}
