#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;

int const maxn = 2e5 + 10;
int cnt;
int head[maxn];
int in[maxn];
int out[maxn];

struct node {
    int v, next;
}e[maxn << 1];
void init() {
    cnt = 0;
    memset(head, -1, sizeof(head));
    memset(in, 0, sizeof(in));
    memset(out, -1, sizeof(out));
}

void add_edge(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

vector<pair<int, int>> edge;

bool topo(int n) {
    queue<int> q;
    int num = 0;
    for (int i = 1; i <= n; i++) {
        if (in[i] == 0) {
            q.emplace(i);
        }
    }
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        out[u] = ++num;
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            if (--in[v] == 0) {
                q.emplace(v);
            }
        }
    }
    if (num == n) {
        return true;
    } else {
        return false;
    }
}

int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        edge.clear();
        init();
        int n, m;
        cin >> n >> m;
        for (int i = 1; i <= m; i++) {
            int ty, u, v;
            cin >> ty >> u >> v;
            if (ty == 0) {
                edge.emplace_back(u, v);
            } else {
                add_edge(u, v);
                in[v]++;
            }
        }
        if (topo(n)) {
            cout << "YES" << endl;
            for (auto & x : edge) {
                int u = x.first, v = x.second;
                if (out[u] > out[v]) {
                    swap(u, v);
                }
                cout << u << " " <<  v << endl;
            }
            for (int i = 1; i <= n; i++) {
                for (int j = head[i]; ~j; j = e[j].next) {
                    int v = e[j].v;
                    cout << i << " " << v << endl;
                }
            }
        } else {
            cout << "NO" << endl;
        }
    }
    return 0;
}
