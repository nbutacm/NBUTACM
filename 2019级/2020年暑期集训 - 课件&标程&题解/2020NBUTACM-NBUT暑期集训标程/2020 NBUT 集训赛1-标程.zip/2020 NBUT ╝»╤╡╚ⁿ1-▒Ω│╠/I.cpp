#include<iostream>

#define ll long long 
#define MAX 0x3f3f3f3f
#define N
 
using namespace std;

int d, n;
bool slove(int x, int y)
{
	if(y-x+d>=0 && y+x-d>=0 && y-x-d<=0 && y+x-2*n+d<=0)
		return true;
	return false;
}

int main()
{
	int m;
	cin>>n >> d;
	cin >> m;
	for(int i = 0; i < m; i++)
	{
		int x, y;
		cin >> x >> y;
		if(slove(x,y))
			cout << "YES" << endl;
		else
			cout << "NO" << endl;
	}
	
	return 0;
}
