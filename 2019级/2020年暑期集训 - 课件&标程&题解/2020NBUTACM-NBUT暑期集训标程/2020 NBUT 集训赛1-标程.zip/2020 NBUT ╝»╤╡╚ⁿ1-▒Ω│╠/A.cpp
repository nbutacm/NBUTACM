#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
int const maxn = 1000000 + 10;
ll a[maxn];

int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n;
        ll s = 0;
        ll mx = 0;
        for (int i = 1; i <= n; i++) {
            cin >> a[i];
            s += a[i];
            mx = max(mx, a[i]);
        }
        ll x = s - mx;
        if (x < mx - 1) {
            cout << "No" << endl;
        } else {
            cout << "Yes" << endl;
        }
    }
    
    return 0;
}
