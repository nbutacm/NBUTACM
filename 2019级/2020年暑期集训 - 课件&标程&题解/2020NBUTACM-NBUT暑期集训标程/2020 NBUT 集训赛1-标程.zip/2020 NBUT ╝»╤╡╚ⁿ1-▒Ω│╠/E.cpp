//#pragma GCC optimize(2)
#include <bits/stdc++.h>
#define ll long long
using namespace std;
const int maxn=2e6+5;
const int mod=1e9+7;
ll t,n,l,r,x,y,s;
 
int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    scanf("%lld",&t);
    while(t--){
        scanf("%lld%lld%lld",&n,&l,&r);
        s=0;
        for(ll i=1;i<=n-1;i++){
            if(s+(n-i)*2<l) s=s+(n-i)*2;
            else{
                for(ll j=s+1;j<=s+(n-i)*2;j++){
                    if(j>=l && j<=r){
                        if((j-s)%2==1) printf("%lld ",i);
                        else printf("%lld ",i+(j-s)/2);
                    }
                }
                s=s+(n-i)*2;
            }
            if(s>=r) break;
        }
        if(s<r) printf("1 ");
        printf("\n");
    }
    return 0;
}
