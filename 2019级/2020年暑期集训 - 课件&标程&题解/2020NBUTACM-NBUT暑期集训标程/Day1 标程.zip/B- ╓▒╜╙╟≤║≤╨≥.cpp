#include<bits/stdc++.h>
using namespace std;
int c[1005],t;
int m;
void high(int pre[],int mid[],int n){
    int i=0,l,r;
    if(n==0) return ;
    while(pre[0]!=mid[i]) i++;
    c[m-1]=pre[0];m--;
    high(pre+i+1,mid+i+1,n-i-1);
	high(pre+1,mid,i);
}
int main(){
    int a[1005],b[1005];
    while(scanf("%d",&t)!=EOF){
	    m=t;
	    for(int i=0;i<t;i++)
	        scanf("%d",&a[i]);
	    for(int i=0;i<t;i++)
	    	scanf("%d",&b[i]);
	    high(a,b,t);
	    for(int i=0;i<t;i++){
	    	printf("%d",c[i]);
			if(i!=t-1) printf(" ");
		}
		printf("\n"); 
	}
	return 0;
}
