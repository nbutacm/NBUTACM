//#include <bits/stdc++.h>
#include <iostream>
#include <iomanip>
#include <bitset>
#include <string>
#include <set>
#include <stack>
#include <sstream>
#include <list>
//#include <array>
#include <vector>
#include <queue>
#include <map>
#include <memory>
#include <iterator>
#include <climits>
#include <cassert>
#include <cstdio>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <algorithm>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define all(x) (x).begin(), (x).end()
typedef long long ll;
typedef unsigned int UINT;
typedef unsigned long long ull;
typedef pair<int, int> pdi;
typedef pair<ll, int> pli;

int const maxn = 1e5 + 10;
const int INF = 0x3f3f3f3f;
const ll INFL = 0x3f3f3f3f3f3f3f3f;
inline int lc(int x)  {return x << 1;}
inline int rc(int x)  {return x << 1 | 1;}

struct node {
    ll val;
    node* lc;
    node* rc;
    node(ll val) : val(val), lc(nullptr), rc(nullptr) {}
};

//����ڵ�
node* Insert(node* root, ll val) {
    if (!root) {
        root = new node(val);
        return root;
    }
    node* now = root;
    while (1) {
        if (root->val > val) {
            if (root->lc == NULL) {
                root->lc = new node(val);
                break;
            }
            root = root->lc;
        } else {
            if (root->rc == NULL) {
                root->rc = new node(val);
                break;
            }
            root = root->rc;
        }
    }
    return now;
}

//ɾ���ڵ�
node* Delete(node* root, ll key) {
    if (!root) return NULL;
    if (root->val > key) {
        root->lc = Delete(root->lc, key);
    } else if (root->val < key) {
        root->rc = Delete(root->rc, key);
    } else {
        if (!root->lc || !root->rc) {
            root = (root->lc) ? root->lc : root->rc;
        } else {
            node* now = root->rc;
            while (now->lc) now = now->lc;
            root->val = now->val;
            root->rc = Delete(root->rc, now->val);
        }
    }
    return root;
}

bool findkey(node *root, ll key) {
    if (root == nullptr) return false;

    while (root) {
        if (root->val == key) {
            return true;
        }
        if (root->val < key) {
            root = root->rc;
        } else {
            root = root->lc;
        }
    }

    return false;
}


void print(node *root) {
    if (!root) return;
    print(root->lc);
    cout << " " << root ->val;
    print(root->rc);
}

void print2(node *root) {
    if (!root) return;
    cout << " " << root ->val;
    print2(root->lc);
    print2(root->rc);
}

int main(void) {
    FAST_IO;
    
    int n;
    cin >> n;
    node *root = nullptr;
    for (int i = 0; i < n; i++) {
        string s;
        cin >> s;
        ll key;
        if (s == "insert") {
            cin >> key;
            root = Insert(root, key);
        } else if (s == "find"){
            cin >> key;
            if (findkey(root, key)) cout << "yes" << endl;
            else cout << "no" << endl;
        } else if (s == "print") {
            print(root);
            cout << endl;
            print2(root);
            cout << endl;
        } else if (s == "delete") {
            cin >> key;
            root = Delete(root, key);
        }
    }
    
    return 0;
}
