#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
int const maxn = 2e5 + 10;

int head, tail, tot;
int n, k;

struct node {
    int val, pre, next;
    node(const int &val = 0) : val(val), next(-1) { }
}a[maxn];
int ans[maxn];

void remove(int p) {
    a[a[p].pre].next = a[p].next;
    a[a[p].next].pre = a[p].pre;
    tot--;
}

set<pair<int, int>> s;

void init() {
    tot = 0;
    head = 0;
    tail = 1;
    for (int i = 1; i <= n; i++) {
        tot++;
        cin >> a[i].val;
        s.insert(make_pair(a[i].val, i));
        a[i].pre = i - 1;
        a[i].next = i + 1;
        tail = i + 1;
    }
}

void select(int id) {
    auto mx = s.rbegin();
    int p = mx->second;
    s.erase(*mx);
    int t = p;
    ans[p] = id;
    for (int i = 0; i < k; i++) {
        if (a[t].pre == head) {
            break; 
        }
        t = a[t].pre;
        s.erase({a[t].val, t});
        ans[t] = id;
        remove(t);
    }
    t = p;
    for (int i = 0; i < k; i++) {
        if (a[t].next == tail) {
            break; 
        }
        t = a[t].next;
        s.erase({a[t].val, t});
        ans[t] = id;
        remove(t);
    }
    s.erase({a[p].val, p});
    remove(p);
}

int main(void) {
    FAST_IO;
    
    cin >> n >> k;
    init();
    int x = 1;
    while (tot > 0) {
        select(x == 1 ? 1 : 2);
        x ^= 1;
    }
    for (int i = 1; i <= n; i++) {
        cout << ans[i];
    }
    cout << endl;

    return 0;
}
