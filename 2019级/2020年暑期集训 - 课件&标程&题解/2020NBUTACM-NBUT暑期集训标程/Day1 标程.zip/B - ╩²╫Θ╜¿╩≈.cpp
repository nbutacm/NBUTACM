#include <bits/stdc++.h>
using namespace std;
int const maxn = 1000 + 10;
int in[maxn], pre[maxn], pos[maxn];
int id;
struct node {
    int val;
    int lc, rc;
    node(const int &v = 0) : val(v), lc(-1), rc(-1) {}
} tree[maxn * 2];
vector<int> v;

void post(int root) {
    if (root == -1) {
        return;
    }
    post(tree[root].lc);
    post(tree[root].rc);
    v.push_back(tree[root].val);
}

int create(int prel, int prer, int inl, int inr) {
    if (prel > prer || inl > inr) {
        return -1;
    }
    ++id;
    int now = id;
    tree[now].val = pre[prel];
    int p = pos[pre[prel]];
    int len = p - inl;
    tree[now].lc = create(prel + 1, prel + len, inl, p - 1);
    tree[now].rc = create(prel + len + 1, prer, p + 1, inr);
    return now;
}

int main(void) {
    int n;
    while (~scanf("%d", &n)) {
        v.clear();
        int num = 0;
        id = 0;
        for (int i = 1; i <= n; i++) {
            scanf("%d", &pre[i]);
        }
        for (int i = 1; i <= n; i++) {
            scanf("%d", &in[i]);
            pos[in[i]] = i;
        }
        int root  = create(1, n, 1, n);
        post(root);
        for (int i = 0; i < v.size(); i++) {
            if (i != 0) printf(" %d", v[i]);
            else printf("%d", v[i]);
        }
        printf("\n");
    }
    
    return 0;
}
