#include <bits/stdc++.h>
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
using namespace std;
int const maxn = 1e5 + 10;
int Next[maxn];
char s[maxn];
int main(void) {
    while (cin.getline(s + 1, maxn - 1)) {
        memset(Next, 0, sizeof(Next));
        int cur = 0, last = 0;
        int len = strlen(s + 1);
        for (int i = 1; i <= len; i++) {
            if (s[i] == '[') {
                cur = 0;
            } else if (s[i] == ']') {
                cur = last;
            } else {
                Next[i] = Next[cur];
                Next[cur] = i;
                if (cur == last) {
                    last = i;
                }
                cur = i;
            }
        }
        for (int i = Next[0]; i; i = Next[i]) {
            cout << s[i];
        }
        cout << endl;
    }

    return 0;
}
