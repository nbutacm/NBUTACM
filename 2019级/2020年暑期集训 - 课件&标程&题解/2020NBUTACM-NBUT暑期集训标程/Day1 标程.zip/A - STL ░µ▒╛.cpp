#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

int const maxn = 1e5 + 10;

int main(void) {
    FAST_IO;
    string s;
    while (getline(cin, s)) {
        list<char> word;
        list<char>::iterator it = word.end();
        for (auto & x : s) {
            if (x == '[') {
                it = word.begin();
            } else if (x == ']') {
                it = word.end();
            } else {
                it = word.insert(it, x);
                it++;
            }
        }
        for (auto &x : word) {
            cout << x;
        }
        cout << endl;
    }
    
    return 0;
}
