#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
int const maxn = 1000 + 10;
int in[maxn], pre[maxn], pos[maxn];
int ans[maxn];
int id;

struct node {
    int val;
    node *lc, *rc;
    node(const int &v = 0) : val(v), lc(nullptr), rc(nullptr) {}
};

void post(node* root) {
    if (!root) {
        return ;
    }
    post(root->lc);
    post(root->rc);
    ans[id++] = root->val;
}

void destory(node* root) {
    if (!root) {
        return ;
    }
    destory(root->lc);
    destory(root->rc);
    delete root;
}

node* create(int prel, int prer, int inl, int inr) {
    if (prel > prer || inl > inr) {
        return nullptr;
    }
    node* root = new node(pre[prel]);
    int p = pos[pre[prel]];
    int len = p - inl;
    root->lc = create(prel + 1, prel + len, inl, p - 1);
    root->rc = create(prel + len + 1, prer, p + 1, inr);
    return root;
}

int main(void) {
    FAST_IO;
    
    int n;
    while (cin >> n) {
        id = 0;
        for (int i = 1; i <= n; i++) {
            cin >> pre[i];
        }
        for (int i = 1; i <= n; i++) {
            cin >> in[i];
            pos[in[i]] = i;
        }
        node *root = create(1, n, 1, n);
        post(root);
        for (int i = 0; i < id; i++)
            if (i != 0) cout << " " << ans[i];
            else cout << ans[i];
        cout << endl;
        destory(root);
    }
    
    return 0;
}
