#include<iostream>
#include<algorithm>
using namespace std;
struct node
{
	int date;
	int pre,next;
	int f;
}que[200002];
struct set
{
	int now;
	int date;
}q[200002];
bool cmp(const set& x,const set& y)
{
	return x.date>y.date;
}
int main()
{
	int n,k;
	int num=0;
	cin>>n>>k;
	for(int i=1;i<=n;i++)
	{
		cin>>que[i].date;
		que[i].pre=i-1;
		que[i].next=i+1;
		que[i].f=0;
		q[i].date=que[i].date;	
		q[i].now=i;
	}
	sort(q+1,q+1+n,cmp);
	int jl=1;
	int tpp=1;
	while(num<n)
	{
		int p=0;
		while(que[q[tpp].now].f!=0&&tpp<=n)
		{
			tpp++;
		}
		p=q[tpp].now;
		que[p].f=jl;
		num++;
		int tk=k;
		int tp=que[p].pre;
		while(tk&&tp!=0&&que[tp].f==0)
		{
			que[tp].f=jl;
			tk--;
			num++;
			que[que[tp].pre].next=que[p].next;
			que[que[p].next].pre=que[tp].pre;
			tp=que[tp].pre;
			
		}
		tk=k;
		tp=que[p].next;
		while(tk&&tp!=n+1&&que[tp].f==0)
		{
			que[tp].f=jl;
			tk--;
			num++;
			que[que[tp].pre].next=que[tp].next;
			que[que[tp].next].pre=que[tp].pre;
			tp=que[tp].next;
			
		}
		if(jl==1)
		jl=2;
		else
		jl=1;
	}
	for(int i=1;i<=n;i++)
	{
		cout<<que[i].f;
	}
	cout<<endl;
return 0;
}
