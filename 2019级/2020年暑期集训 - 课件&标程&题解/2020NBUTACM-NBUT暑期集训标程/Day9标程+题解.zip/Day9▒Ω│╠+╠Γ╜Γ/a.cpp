//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e4+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp[maxn][2],in[maxn],gg;    //dp[i][1]表示i去参加宴会的最大快乐值，反之则不去的最大快乐值
struct node{         
    ll next,to;    //next表示与第i条边同起点的下一条边的序号,to表示第i条边的终点
}e[maxn];
ll head[maxn],tot;   //head数组记录了以i为起点的第一条边的序号。tot表示边数

inline void add(ll u,ll v){     //链式前向星存图
    tot++;
    e[tot]={head[u],v};
    head[u]=tot;
}

void dfs(ll u){
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;     //每次找到他的儿子节点编号
        dfs(v);        //每次找下去
        dp[u][0]+=max(dp[v][0],dp[v][1]);    //如果u没去则有两种选择
        dp[u][1]+=dp[v][0];    //如果u去了那么只有一种选择
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    while(~sc(n)){
        memset(dp,0,sizeof(dp));
        memset(in,0,sizeof(in));
        memset(head,0,sizeof(head));
        memset(e,0,sizeof(e));
        tot=0;
        for(int i=1;i<=n;i++) sc(dp[i][1]);
        ll u,v;
        while(scanf("%lld %lld",&u,&v) && u && v){
            add(v,u);
            in[u]++;
        }
        for(int i=1;i<=n;i++){
            if(!in[i]){
                gg=i;
                break;
            }
        }
        dfs(gg);
        pr(max(dp[gg][1],dp[gg][0]));
    }
    return 0;
}