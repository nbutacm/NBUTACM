//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e4+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp[maxn][2];    //dp[i][1]表示i处放士兵的最小值，否则相反
struct node{         
    ll next,to;    //next表示与第i条边同起点的下一条边的序号,to表示第i条边的终点
}e[maxn];
ll head[maxn],tot;   //head数组记录了以i为起点的第一条边的序号。tot表示边数

inline void add(ll u,ll v){     //链式前向星存图
    tot++;
    e[tot]={head[u],v};
    head[u]=tot;
}

void dfs(ll u,ll fa){
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;     //每次找到他的儿子节点编号
        if(v==fa) continue;
        dfs(v,u);        //每次找下去
        dp[u][1]+=min(dp[v][0],dp[v][1]);    //放了就无所谓，选个小的
        dp[u][0]+=dp[v][1];    //如果不放置士兵那么按照题意子节点就要全放士兵，因为要满足士兵能看到所有边
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(n);
    for(int i=1;i<=n;i++){
        ll v,u,k;
        sc(u),sc(k);
        dp[u][1]=1;
        for(int j=1;j<=k;j++){
            sc(v);
            add(u,v);
            add(v,u);
        }
    }
    dfs(0,-1);
    pr(min(dp[0][1],dp[0][0]));
    return 0;
}