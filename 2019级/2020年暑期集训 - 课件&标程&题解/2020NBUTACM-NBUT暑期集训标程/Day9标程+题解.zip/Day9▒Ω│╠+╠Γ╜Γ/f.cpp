//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=4e5+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,dp[maxn],ans[maxn];    //dp[i]表示以i为根节点的最大值,ans[i]表示i节点的子树个数
struct node{         
    ll next,to;    //next表示与第i条边同起点的下一条边的序号,to表示第i条边的终点
}e[maxn];
ll head[maxn],tot,s;   //head数组记录了以i为起点的第一条边的序号。tot表示边数

inline void add(ll u,ll v){     //链式前向星存图
    tot++;
    e[tot]={head[u],v};
    head[u]=tot;
}

void dfs1(ll u,ll fa){    //第一遍先求出以1为根节点的涂色方案
    ans[u]=0;
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;
        if(v==fa) continue;    //因为存的双向边，所以如果是他的父节点直接跳过，不然会重复计算
        dfs1(v,u);
        ans[u]+=ans[v];
        dp[u]+=dp[v];
    }
    ans[u]++;
    dp[u]+=ans[u];
}

void dfs2(ll u,ll fa){
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;
        if(v==fa) continue;
        dp[v]=dp[u]+dp[1]-2*ans[v];    //父节点值-父节点包含的子树的值+除了该点的子树剩余节点的数量
        s=max(s,dp[v]);
        dfs2(v,u);
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(n);
    for(int i=1;i<n;i++){
        ll u,v;
        sc(u),sc(v);
        add(u,v);      //无向图存双向边
        add(v,u);
    }
    dfs1(1,1);
    s=dp[1];
    dfs2(1,1);
    pr(s);
    return 0;
}