//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=505;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,m,dp[maxn][maxn];    //dp[i][j]表示以i节点为根节点，选j门课的最大学分
struct node{         
    ll next,to;    //next表示与第i条边同起点的下一条边的序号,to表示第i条边的终点
}e[maxn];
ll head[maxn],tot;   //head数组记录了以i为起点的第一条边的序号.tot表示边数

inline void add(ll u,ll v){     //链式前向星存图
    tot++;
    e[tot]={head[u],v};
    head[u]=tot;
}

void dfs(ll u){
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;
        dfs(v);
        for(int j=m+1;j;j--){     //枚举该节点的可能
            for(int k=0;k<j;k++){     //枚举该节点子树的可能
                dp[u][j]=max(dp[u][j],dp[u][j-k]+dp[v][k]);   //枚举所有可能
            }
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(n),sc(m);
    for(int i=1;i<=n;i++){
        ll u,w;
        sc(u),sc(dp[i][1]);
        add(u,i);     //把0当做根节点，最后就是多出个0节点选m+1门课
    }
    dfs(0);
    pr(dp[0][m+1]);
    return 0;
}