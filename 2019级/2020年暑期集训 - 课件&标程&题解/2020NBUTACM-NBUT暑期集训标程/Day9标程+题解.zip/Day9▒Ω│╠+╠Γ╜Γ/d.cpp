//#pragma GCC oplmize(2)
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=505;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll n,q,dp[maxn][maxn];    //dp[i][j]表示i的子树上保留j条边的最多苹果数
struct node{         
    ll next,to,w;    //next表示与第i条边同起点的下一条边的序号,to表示第i条边的终点,w表示权值
}e[maxn];
ll head[maxn],tot;   //head数组记录了以i为起点的第一条边的序号。tot表示边数

inline void add(ll u,ll v,ll w){     //链式前向星存图
    tot++;
    e[tot]={head[u],v,w};
    head[u]=tot;
}

void dfs(ll u,ll fa){
    for(int i=head[u];i;i=e[i].next){
        ll v=e[i].to;
        if(v==fa) continue;    //因为存的双向边，所以如果是他的父节点直接跳过，不然会重复计算
        dfs(v,u);
        for(int j=q;j;j--){     //枚举该节点的边数
            for(int k=0;k<=j-1;k++){     //枚举该节点子树的边数
                dp[u][j]=max(dp[u][j],dp[u][j-k-1]+dp[v][k]+e[i].w);   //-1是因为要保留u-v的那一条边
                //cout<<dp[u][j]<<endl;
            }
        }
    }
}

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(n),sc(q);
    for(int i=1;i<n;i++){
        ll u,v,w;
        sc(u),sc(v),sc(w);
        add(u,v,w);      //无向图存双向边
        add(v,u,w);
    }
    dfs(1,0);
    pr(dp[1][q]);
    return 0;
}