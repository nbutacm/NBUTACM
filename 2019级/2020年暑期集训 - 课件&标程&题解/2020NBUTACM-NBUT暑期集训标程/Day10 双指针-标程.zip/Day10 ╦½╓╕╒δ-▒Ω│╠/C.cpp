#include <iostream>
#include <cstring>
#include <algorithm>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
int const maxn = 1e5 + 10;
const int INF = 0x3f3f3f3f;

int n, m;
ll a[maxn];
pair<ll, int> pre[maxn];


int main(void) {
    FAST_IO;

    while (cin >> n >> m) {
        if (n == 0 && m == 0) break;
        pre[0].first = pre[0].second = 0;
        for (int i = 1; i <= n; i++) {
            cin >> a[i];
            pre[i].first = pre[i - 1].first + a[i];
            pre[i].second = i;
        }
        sort(pre, pre + 1 + n);

        while (m--) {
            ll t;
            cin >> t;
            ll ans = INF, l = 0, r = 1;
            ll temp = INF;
            int ansl = 0, ansr = 0;
            while (r <= n) {
                ll x = pre[r].first - pre[l].first;
                if (abs((int)(x - t)) < temp) {
                    temp = abs((int)(x - t));
                    ans = x;
                    ansl = pre[l].second;
                    ansr = pre[r].second;
                }
                if (x < t) {
                    r++;
                } else if (x > t) {
                    l++;
                } else {
                    break;
                }
                if (l == r) r++;
            }
            if (ansl > ansr) swap(ansl, ansr);
            cout << ans << " " << ansl+1 << " " << ansr << endl;
        }
    }
    
    return 0;
}
