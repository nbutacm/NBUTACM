#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
int const maxn = 1000000 + 10;
int a[30];
char s[maxn];
int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        int k;
        cin >> s >> k;
        int len = strlen(s);
        int l = 0, r = 0;
        ll cnt = 0;
        memset(a, 0, sizeof(a));
        cnt++;
        a[s[0] - 'a']++;
        ll ans = 0;
        while (l <= r && r < len) {
            if (cnt >= k) {
                ans += len - r;
                a[s[l] - 'a']--;
                if (a[s[l] - 'a'] == 0) cnt--;
                l++;
            } else {
                r++;
                if (a[s[r] - 'a'] == 0) cnt++;
                a[s[r] - 'a']++;
            }
        }
        cout << ans << endl;
    }
    
    return 0;
}
