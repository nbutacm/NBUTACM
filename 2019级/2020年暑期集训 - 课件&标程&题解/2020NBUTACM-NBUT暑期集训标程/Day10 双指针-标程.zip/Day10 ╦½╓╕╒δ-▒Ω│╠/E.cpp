#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
int const maxn = 2e5 + 10;
const int INF = 0x3f3f3f3f;

int n, a[maxn];
int vis[maxn];
int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        cin >> n;
        memset(vis, 0, sizeof(vis));
        for (int i = 1; i <= n; i++) {
            cin >> a[i];
        }
        int l = 1, r = 1;
        int ans = INF, mx = 0;
        while (l <= r && r <= n) {
            vis[a[r]]++;
            if (vis[a[r]] == 2) {
                while (vis[a[r]] == 2) {
                    vis[a[l]]--;
                    l++;
                }
                ans = min(ans, r - l + 2);
            }
            r++;
        }
        if (ans == INF) cout << -1 << endl;
        else cout << ans << endl;
    }
    return 0;
}
