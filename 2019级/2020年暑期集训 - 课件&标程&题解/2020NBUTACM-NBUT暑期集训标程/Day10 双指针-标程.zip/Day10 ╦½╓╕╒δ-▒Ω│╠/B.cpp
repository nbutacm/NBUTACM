#include <iostream>
#include <cstdio>
#include <cstring> 
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;
int const maxn = 1e5 + 10;
const int INF = 0x3f3f3f3f;

ll a[maxn], s;
int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        int n;
        cin >> n >> s;
        for (int i = 1; i <= n; i++) {
            cin  >> a[i];
        }
        ll ans = INF, l = 0, r = 0;
        ll temp = 0;
        while (1) {
            while (r < n && temp < s) {
                temp += a[++r];
            }
            if (temp < s) {
                break;
            }
            ans = min(ans, r - l);
            temp -= a[++l];
        }
        if (ans == INF) cout << 0 << endl;
        else cout << ans << endl;
    }
    
    return 0;
}
