#include <iostream>
#include <cstdio>
#include <cstring>
#include <vector> 
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
#define emplace_back push_back
typedef long long ll;
int const maxn = 1e5 + 10;
const int INF = 0x3f3f3f3f;
vector<int> p;

bool prime(int x) {
    if (x == 1) return false;
    for (int i = 2; i * i <= x; i++) {
        if (x % i == 0) return false;
    }
    return true;
}

void init() {
    // p.emplace_back(1);
    for (int i = 2; i <= 10000; i++) {
        if (prime(i)) p.emplace_back(i);
    }
}

int main(void) {
    FAST_IO;
    
    init();
    int n;
    while (cin >>n) {
        if (n == 0) break;
        int ans = 0, l = 0, r = 0;
        int temp = 0;
        while (1) {
            if (temp == n) ans++;
            if (temp >= n){ 
                temp -= p[l++];
            } else {
                if (p[r] > n) break;
                temp += p[r++];
            }
        }
        cout << ans <<endl;
    }
    
    return 0;
}
