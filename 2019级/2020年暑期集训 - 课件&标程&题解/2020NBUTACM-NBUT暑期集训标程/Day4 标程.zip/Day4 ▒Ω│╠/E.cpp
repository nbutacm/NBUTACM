#include <iostream>
#include <cstring> 
#include <queue>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

int const maxn = 3000 + 10;

struct node {
    int v, w, next;
} e[maxn << 1];
int head[maxn], cnt;
int n, m, w;
int dis[maxn], vis[maxn], in[maxn];

void init() {
    memset(head, -1, sizeof(head));
    memset(in, 0, sizeof(in));
    memset(vis, 0, sizeof(vis));
    cnt = 0;
}

void add(int u, int v, int w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

bool SPFA(int st) {
    memset(dis, 0x3f, sizeof(dis));
    dis[st] = 0;
    queue<int> q;
    q.push(st);
    vis[st] = 1;
    in[st] = 1;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        vis[u] = 0;
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            int cost = e[i].w;
            if (dis[v] > dis[u] + cost) {
                dis[v] = dis[u] + cost;
                if (!vis[v]){
                    q.push(v);
                    vis[v] = 1;
                    if (++in[v] >= n) return true;
                } 
            } 
        }
    }
    return false;
}

int main(void) {
    FAST_IO;
    
    int t;
    cin >> t;
    while (t--) {
        init();
        cin >> n >> m >> w;
        for (int i = 0; i < m; i++) {
            int u, v, cost;
            cin >> u >> v >> cost;
            add(u, v, cost);
            add(v, u, cost);
        }
        for (int i = 0; i < w; i++) {
            int u, v, cost;
            cin >> u >> v >> cost;
            add(u, v, -cost);
        }
        if (SPFA(1)) {
            cout <<"YES" <<endl;
        } else {
            cout << "NO" << endl;
        }
    }

    return 0;
}
