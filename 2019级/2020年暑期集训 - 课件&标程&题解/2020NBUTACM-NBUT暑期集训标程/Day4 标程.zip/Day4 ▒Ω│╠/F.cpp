#include <bits/stdc++.h>

using namespace std;
int const maxn = 1e3 + 10;
pair<int, int> p[maxn];
int a[maxn];
int dp[maxn][maxn];

int distance(pair<int, int> &x, pair<int, int> &y) {
    return abs(x.first - y.first) + abs(y.second - x.second);
}

void flody(int n) {
    for (int k = 1; k <= n; k++) {
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                dp[i][j] = min(dp[i][j], dp[i][k] + dp[k][j]);
            }
        }
    }
}

int main(void) {
    memset(dp, 0x3f, sizeof(dp));
    int n, d;
    cin >> n >> d;

    for (int i = 2; i < n; i++) {
        cin >> a[i];
    }
    for (int i = 1; i <= n; i++) {
        dp[i][i] = 0;
        cin >> p[i].first >> p[i].second;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= n; j++) {
            if (i != j) {
                dp[i][j] = d * distance(p[i], p[j]) - a[i];
            }
        }
    }
    flody(n);
    cout << dp[1][n] << endl;

    return 0;
}
