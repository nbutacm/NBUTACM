#include <bits/stdc++.h>
#define FAST_IO std::ios::sync_with_stdio(false),std::cin.tie(0),std::cout.tie(0)

using namespace std;
typedef long long ll;
int const maxn = 1e5 + 10;
int const INFL = 0x7f7f7f7f7f7f7f7f;
int n, m;
int cnt;
int head[maxn], pre[maxn];
int vis[maxn];
struct node {
    int v, next;
    ll w;
}e[maxn << 1];
ll dis[maxn];

void add_edge(int u, int v, ll w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void init() {
    cnt = 0;
    memset(pre, -1, sizeof(pre));
    memset(head, -1, sizeof(head));
}

ll dijkstra(int s, int t) {
    for (int i = 1; i <= n; i++) {
        dis[i] = 1e18;
        // cout << dis[i] << endl;
        vis[i] = 0;
    }
    priority_queue<pair<ll, int>> q;
    dis[s] = 0;
    q.push({0, s});
    while (!q.empty()) {
        int u = q.top().second;
        // cout << u << endl;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            int w = e[i].w;
            if (dis[v] > dis[u] + w) {
                dis[v] = dis[u] + w;
                q.push({-dis[v], v});
                pre[v] = u;
            }
        }
    }
    if (dis[t] == 1e18) {
        return -1;
    }
    return dis[t];
}

void print(int x) {
    if (x == -1) {
        return;
    }
    print(pre[x]);
    cout << x << " ";
}

int main(void) {
    FAST_IO;
    cin >> n >> m;
    init();
    for (int i = 1; i <= m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        add_edge(u, v, w);
        add_edge(v, u, w);
    }
    ll ans = dijkstra(1, n);
    // cout << ans <<endl;
    if (ans != -1) {
        print(n);
        cout << endl;
    } else cout << ans << endl;

    return 0;
}
