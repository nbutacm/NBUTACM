#include <iostream>
#include <string>
#include <vector>
#include <queue>
#include <cstdio>
#include <cstring>
#include <algorithm>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
int const maxn = 3e6 + 10;

int head[maxn], cnt;
int vis[maxn], n, m;
int dis[maxn];
struct node {
    int v, w, next;
} e[maxn << 1];

void add(int u, int v, int w) {
    e[cnt].w = w;
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void init() {
    memset(head, -1, sizeof(head));
    cnt = 0;
}

int dijkstra(int st, int ed) {
    memset(dis, 0x3f, sizeof(dis));
    dis[st] = 0;
    priority_queue<pair<int, int> > q;
    q.push(make_pair(0, st));

    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            int w = e[i].w;
            if (dis[v] > dis[u] + w) {
                dis[v] = dis[u] + w;
                q.push(make_pair(-dis[v], v));
            }
        }
    }

    return dis[ed];
}

int main(void) {
    FAST_IO;
    
    init();

    scanf("%d %d", &n, &m);
    for (int i = 0; i < m; i++) {
        int u, v, w;
        scanf("%d %d %d", &u, &v, &w);
        add(u, v, w);
    }
    printf("%d\n", dijkstra(1, n));
    
    return 0;
}
