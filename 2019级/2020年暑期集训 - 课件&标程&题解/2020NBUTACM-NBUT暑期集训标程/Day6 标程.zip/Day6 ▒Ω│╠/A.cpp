#include <iostream>
#include <cstdio>
#include <cstring>
#include <queue>

using namespace std;
typedef long long ll;
int const maxn = 10000;
int const INF = 0x3f3f3f3f;

int cnt, head[maxn], dis[maxn];
int vis[maxn];
struct node {
    int v, w, next;
}e [maxn << 1];

void add_edge(int u, int v, int w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void init() {
    cnt = 0;
    memset(head, -1, sizeof(head));
}

void dijstrka(int mid) {
    priority_queue<pair<int, int> > q;
    memset(dis, 0x3f, sizeof(dis));
    memset(vis, 0, sizeof(vis));
    dis[1] = 0;
    q.push(make_pair(0, 1));
    while (!q.empty()) {
        int u = q.top().second;
        q.pop();
        if (vis[u]) continue;
        vis[u] = 1;
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            int w = e[i].w;
            w = (w > mid ? 1 : 0);
            if (dis[v] > dis[u] + w) {
                dis[v] = dis[u] + w;
                q.push(make_pair(-dis[v], v));
            }
        }
    }
}

int main(void) {
    int n, m, k;
    init();
    cin >> n >> m >> k;
    int l = 0, r = 0;
    for (int i = 1; i <= m; i++) {
        int u, v, w;
        cin >> u >> v >> w;
        r = max(w, r);
        add_edge(u, v, w);
        add_edge(v, u, w);
    }
    ll ans = -1;
    while (l <= r) {
        int mid = l + r >> 1;
        dijstrka(mid);
        if (dis[n] <= k) {
            r = mid - 1;
            ans = mid;
        } else {
            l = mid + 1;
        }
    }
    cout << ans << endl;
    return 0;
}
