#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int const maxn = 300 + 10;
int fa[maxn];
struct node {
    int u, v, w;
    bool operator<(const node &_obj) const {
        return w < _obj.w;
    }
} e[maxn * maxn];
int cnt;

void init(int n) {
    cnt = 0;
    for (int i = 0; i <= n; i++) {
        fa[i] = i;
    }
}

int find(int x) {
    return fa[x] == x ? x : fa[x] = find(fa[x]);
}

ll MST(int n) {
    sort(e, e + cnt);
    ll ans = 0;
    int set_num = n;
    for (int i = 0; i < cnt; i++) {
        int fx = find(e[i].u);
        int fy = find(e[i].v);
        if (fx != fy) {
            fa[fx] = fy;
            set_num--;
            ans += e[i].w;
        }
    }
    return ans;
}

int main(void) {
    int k;
    int n;
    while (cin >> n) {
        init(n);
        for (int i = 1; i <= n; i++) {
            int w;
            cin >> w;
            e[cnt].u = 0;
            e[cnt].v = i;
            e[cnt].w = w;
            cnt++;
        }
        for (int i = 1; i <= n; i++) {
            for (int j = 1; j <= n; j++) {
                int w;
                cin >> w;
                if (i < j) {
                    e[cnt].u = i, e[cnt].v = j, e[cnt].w = w;
                    cnt++;
                }
            }
        }
        cout << MST(n) << endl;
    }

    return 0;
}
