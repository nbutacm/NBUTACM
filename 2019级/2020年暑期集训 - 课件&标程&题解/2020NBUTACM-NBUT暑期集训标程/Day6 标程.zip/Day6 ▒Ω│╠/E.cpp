#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int const maxn = 100000 + 10;
struct node {
    int v, next;
} e[maxn];
int head[maxn], cnt;
vector<int> in, tep;

void add_edge(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void init() {
    cnt = 0;
    memset(head, -1, sizeof(head));
}

bool topo(int n) {
    int num = 0;
    queue<int> q;
    for (int i = 1; i <= n; i++) {
        if (in[i] == 0) {
            q.emplace(i);
        }
    }
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        num++;
        for (int i = head[u]; ~i ; i = e[i].next) {
            int v = e[i].v;
            if (--in[v] == 0) {
                q.emplace(v);
            }
        }
    }
    if (n == num) return true;
    return false;
}

int main(void) {
    int n, m;
    cin >> n >> m;
    init();
    in.resize(n + 1);
    tep.resize(n + 1);
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        add_edge(u, v);
        in[v]++;
    }
    tep = in;
    int f = 0;
    for (int i = 1; i <= n; i++) {
        in = tep;
        if (in[i]) in[i]--;
        if (topo(n)) {
            f = 1;
            break;
        }
    }
    if (f) cout << "YES" << endl;
    else cout << "NO" << endl;

    return 0;
}
