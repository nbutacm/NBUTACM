#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

int const maxn = (1000 << 1) + 10;
vector<int> e[maxn];
int in[maxn];
int n, m, set_num;
int fa[maxn];
char mp[maxn][maxn];
int cnt, flag;
int ans[maxn];

void init() {
    for (int i = 1; i <= n + m; i++) {
        fa[i] = i;
    }
    set_num = n + m;
}

int find(int x) {
    return x == fa[x] ? x : fa[x] = find(fa[x]);
}

bool unio(int x, int y) {
    int fx = find(x), fy = find(y);
    if (fx != fy) {
        fa[fx] = fy;
        set_num--;
        return false;
    }
    return true;
}

void toposort() {
    queue<int> q;
    for (int i = 1; i <= n + m; i++) {
        if (!in[i] && find(i) == i) q.push(i);
    }
    int num = 0;
    while (!q.empty()) {
        int sz = q.size();
        num++;
        while (sz--) {
            int u = q.front();
            q.pop();
            cnt--;
            ans[u] = num;
            for (auto &v : e[u]) {
                if (--in[v] == 0) {
                    q.push(v);
                }
            }
        }
    }
    if (cnt != 0) {
        flag = 1;
    }
}


int main(void) {
    FAST_IO;
    
    cin >> n >> m;
    init();
    for (int i = 1; i <= n; i++) {
        cin >> mp[i] + 1;
    }
    for (int i = 1; i <= n; i++) {
        for (int j = 1; j <= m; j++) {
            if (mp[i][j] == '=') {
                unio(i, n + j);
                // set_num--;
            }
        }
    }
    cnt = set_num;
    for (int i = 1; i <= n; i++) {
        if (flag) {
            break;
        }
        for (int j = 1; j <= m; j++) {
            if (mp[i][j] == '=') continue;
            
            int u = find(i), v = find(n + j);
            if (u == v) {
                flag = 1;
                break;
            }
            if (mp[i][j] == '<') {
                e[u].push_back(v);
                in[v]++;
            } else {
                e[v].push_back(u);
                in[u]++;
            }
        }
    }
    toposort();
    if (flag) {
        cout << "NO" << endl;
    } else {
        cout << "YES" << endl;
        for (int i = 1; i <= n; i++) {
            cout << ans[find(i)] << " ";
        }
        cout << endl;
        for (int i = 1; i <= m; i++) {
            cout << ans[find(i + n)] << " ";
        }
        cout << endl;
    } 

    return 0;
}
