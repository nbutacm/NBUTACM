#include <bits/stdc++.h>
#define FAST_IO std::ios::sync_with_stdio(false),std::cout.tie(0),std::cin.tie(0)

using namespace std;
int const maxn = 100000 + 10;
int fa[maxn];
int ans[maxn];
vector<pair<int, int>> e;
int n, m;

int set_num;

void init() {
    set_num = n;
    for (int i = 0; i < n; i++) {
        fa[i] = i;
    }
}

int find(int x) {
    return x == fa[x] ? x : fa[x] = find(fa[x]);
}

bool merge(int x, int y) {
    int fx = find(x);
    int fy = find(y);
    if (fx != fy) {
        fa[fx] = fy;
        set_num--;
        return false;
    }
    return true;
}

int main(void) {
    while (~scanf("%d%d", &n, &m)) {
        init();
        e.clear();
        for (int i = 0; i < m; i++) {
            int u, v;
            scanf("%d %d", &u, &v);
            e.push_back(make_pair(u, v));
        }
        for (int i = m - 1; i >= 0; i--) {
            int u = e[i].first, v = e[i].second;
            ans[i] = set_num;
            merge(u, v);
        }
        for (int i = 0; i < m; i++) {
            printf("%d\n", ans[i]);
        }
    }

    return 0;
}
