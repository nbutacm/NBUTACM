#include <bits/stdc++.h>
using namespace std;
typedef long long ll;
int const maxn = 1000000 + 10;

struct node {
    int v, w, next;
} e[maxn << 1];
int n, m;
int cnt;
int ans;
int head[100000 + 10], vis[100000 + 10];
int fa[100000 + 10];
int dis[100000 + 10];
int flag;


void add(int u, int v, int w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void init() {
    cnt = 0;
    flag = 0;
    ans = 0;
    memset(head, -1, sizeof(head));
    for (int i = 1; i <= n; i++) {
        fa[i] = i;
        vis[i] = 0;
        dis[i] = 0;
    }
}

int find(int x) {
    return fa[x] == x ? x : fa[x] = find(fa[x]);
}

bool merge(int x, int y) {
    int fx = find(x), fy = find(y);
    if (fx != fy) {
        fa[fx] = fy;
        return false;
    } 
    return true;
}

void dfs(int x){
    vis[x] = 1;
    for (int i = head[x]; ~i; i = e[i].next) {
        int y = e[i].v;
        if (vis[y]) continue;
        dfs(y);
        ans = max(ans, dis[x] + dis[y] + e[i].w);
        dis[x] = max(dis[x], dis[y] + e[i].w);
    }
}


int main(void) {

    while (~scanf("%d %d", &n, &m)) {
        init();
        for (int i = 1; i <= m; i++) {
            int u, v, w;
            scanf("%d %d %d", &u, &v, &w);
            add(u, v, w);
            add(v, u, w);
            if (merge(u, v)) {
                flag = 1;
            }
        }
        if (flag) {
            printf("YES\n");
        } else {
            for (int i = 1; i <= n; i++) {
                if (!vis[i]) {
                    dfs(i);
                }
            }
            printf("%d\n", ans);
        }
    }

    return 0;
}
