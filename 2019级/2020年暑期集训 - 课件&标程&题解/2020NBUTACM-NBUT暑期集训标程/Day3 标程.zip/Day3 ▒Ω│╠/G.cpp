#include <iostream>
#include <vector>
#include <cstdio>
#include <algorithm>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
typedef long long ll;

int const maxn = 2e4 + 10;
int n;

struct node {
    int l, r, id;
} q[maxn];
int fa[maxn], dis[maxn];

void init() {
    for (int i = 0; i < maxn; i++) {
        fa[i] = i;
        dis[i] = 0;
    }    
}

int find(int x) {
    if (fa[x] == x) return x;
    int fx = fa[x];
    int root = find(fa[x]);
    dis[x] ^= dis[fx];
    return fa[x] = root;
}

bool unio(int x, int y, int id) {
    int fx = find(x), fy = find(y);
    if (fx != fy) {
        // if (fx > fy) swap(fx, fy);
        fa[fx] = fy;
        dis[fx]  = dis[y] ^ dis[x] ^ id;
        return true;
    }
    if (dis[x] ^ dis[y] != id) return false; 
    return true;
}

int main(void) {
    FAST_IO;
    
    int n, m;
    cin >> n >> m;
    init();
    vector<int> v;
    for (int i = 1; i <= m; i++) {
        string s;
        cin >> q[i].l >> q[i].r >> s;
        q[i].l--;
        if (s == "even") q[i].id = 0;
        else q[i].id = 1;
        v.push_back(q[i].l);
        v.push_back(q[i].r);
    }
    sort(v.begin(), v.end());
    v.erase(unique(v.begin(), v.end()), v.end());
    // for (auto &x : v) {
    //     cout << x << " ";
    // }
    int ans = m;
    for (int i = 1; i <= m; i++) {
        q[i].l = lower_bound(v.begin(), v.end(), q[i].l) - v.begin();
        q[i].r = lower_bound(v.begin(), v.end(), q[i].r) - v.begin();
        // cout << q[i].l << "  " << q[i].r << endl;
        if (!unio(q[i].l, q[i].r, q[i].id)) {
            ans = i - 1;
            break;
        }
    }
    cout << ans << endl;
    
    return 0;
}
