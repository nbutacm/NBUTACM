#include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)

int const maxn = 2e5 + 10;

int head[maxn], cnt;
int fa[maxn][25];
int dep[maxn], n;
int vis[maxn], p[maxn];

struct node {
    int v, next;
} e[maxn << 1];

void init() {
    memset(head, -1, sizeof(head));
    cnt = 0;
}

void add(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void dfs(int u, int v) {
    if (vis[u]) return;
    vis[u] = 1;
    fa[u][0] = v;
    for (int i = head[u]; ~i; i = e[i].next) {
        int x = e[i].v;
        if (v == x) continue;
        dep[x] = dep[u] + 1;
        dfs(x, u);
    }
}

void doubly() {
    dfs(1, 1);
    for (int j = 1; j <= 20; j++) {
        for (int i = 1; i <= n; i++) {
            fa[i][j] = fa[fa[i][j - 1]][j - 1];
        }
    }
}

int lca(int u, int v) {
    if (dep[u] > dep[v]) {
        swap(u, v);
    }
    for (int i = 20; i >= 0; i--) {
        if ((dep[v] - (1 << i)) >= dep[u]) {
            v = fa[v][i];
        }
    }
    if (u == v) return u;
    for (int i = 20; i >= 0; i--) {
        if (fa[u][i] != fa[v][i]) {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[v][0];
}

int main(void) {
    FAST_IO;
    
    int m;
    cin >> n >> m;
    init();
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        cin >> u >> v;
        add(u, v);
        add(v, u);
    }
    doubly();
    while (m--) {
        int k;
        cin >> k;
        for (int i = 1; i <= k; i++) {
            cin >> p[i];
        }
        for (int i = 1; i <= k; i++) {
            p[i] = fa[p[i]][0];
        }
        sort(p + 1, p + 1 + k, [](const int &u, int const &v) {
            return dep[u] < dep[v];
        });
        int flag = 1;
        for (int i = 1; i < k; i++) {
            if (lca(p[i], p[i + 1]) != p[i]) {
                flag = 0;
                break;
            }
        }
        if (flag) {
            cout << "YES" << endl;
        } else {
            cout << "NO" << endl;
        }
    }
    return 0;
}
