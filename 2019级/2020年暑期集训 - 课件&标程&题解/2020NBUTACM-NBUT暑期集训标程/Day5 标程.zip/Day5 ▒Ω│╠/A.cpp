// HDU - 2586
// LCA ���� DFS �����ϱ���ģ��
#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#define FAST_IO std::ios::sync_with_stdio(false),std::cin.tie(0),std::cout.tie(0)

using namespace std;
typedef long long ll;
int const maxn = 40000 + 10;
int const maxm = 40000 + 10;
int vis[maxn], head[maxn];
int fa[maxn][25], dep[maxn], cnt;
int dis[maxn];

struct node {
    int v, next, w;
}e[maxm << 1];

void init() {
    memset(head, -1, sizeof(head));
    memset(vis, 0, sizeof(vis));
    memset(dis, 0, sizeof(dis));
    cnt = 0;
}

void add_edge(int u, int v, int w) {
    e[cnt].v = v;
    e[cnt].w = w;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

// ������� O(n)
void dfs(int u, int f){
    if (vis[u]) return;
    vis[u] = 1;
    fa[u][0] = f;
    for (int i = head[u]; ~i ; i = e[i].next){
        int v = e[i].v;
        if (f == v) {
            continue;
        }
        dis[v] = dis[u] + e[i].w;
        dep[v] = dep[u] + 1;
        dfs(v, u);
    }
}

// ����Ԥ���� LCA ���Ӷȣ� O(n * logn)
void doubly(int n){
    dfs(1, 1);
    for (int j = 1; j <= 20; j++){
        for (int i = 1; i <= n; i++){
            fa[i][j] = fa[fa[i][j - 1]][j - 1];
        }
    }
}

// �������� LCA ���Ӷȣ�O(logn)
int lca(int u, int v) {
    // ���� dep[v] >= dep[u]
    if (dep[u] > dep[v]) {
        swap(u, v);
    }
    // ���ϵĵ��� ֱ��u��v�������ͬһ�㡣
    for (int i = 20; i >= 0; i--) {
        if ((dep[v] - (1 << i)) >= dep[u]) {
            v = fa[v][i];
        }
    }
    if (u == v) return u;
    // һ�������� 2 ^ i ��
    for (int i = 20; i >= 0; i--) {
        if (fa[u][i] != fa[v][i]) {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[v][0];
}

int main(void) {
    FAST_IO;
    int t;
    cin >> t;
    while (t--) {
        init();
        int n, m;
        cin >> n >> m;
        for (int i = 1; i < n; i++) {
            int u, v, w;
            cin >> u >> v >> w;
            add_edge(u, v, w);
            add_edge(v, u, w);
        }
        // ����Ԥ����
        doubly(n);
        while (m--) {
            int x, y, z;
            cin >> x >> y;
            z = lca(x, y);
            cout << dis[x] + dis[y] - 2 * dis[z] << endl;
        }
    }

    return 0;
}
