#include <iostream>
#include <cstring>
#include <cstdio>
#include <vector>
#define FAST_IO std::ios::sync_with_stdio(false),std::cin.tie(0),std::cout.tie(0)

using namespace std;
typedef long long ll;
int const maxn = 100000 + 10;
int const maxm = 200000 + 10;
int vis[maxn], head[maxn];
int fa[maxn][25], dep[maxn], cnt;
int dis[maxn];

struct node {
    int v, next;
}e[maxm << 1];

void init() {
    memset(head, -1, sizeof(head));
    memset(vis, 0, sizeof(vis));
    cnt = 0;
}

void add_edge(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void dfs(int u, int v){
    if (vis[u]) return;
    vis[u] = 1;
    fa[u][0] = v;
    for (int i = head[u]; ~i ; i = e[i].next){
        int x = e[i].v;
        if (v == x) {
            continue;
        }
        dep[x] = dep[u] + 1;
        dfs(x, u);
    }
}

void doubly(int n){
    dfs(1, 1);
    for (int j = 1; j <= 20; j++){
        for (int i = 1; i <= n; i++){
            fa[i][j] = fa[fa[i][j - 1]][j - 1];
        }
    }
}

int lca(int u, int v) {
    if (dep[u] > dep[v]) {
        swap(u, v);
    }
    for (int i = 20; i >= 0; i--) {
        if ((dep[v] - (1 << i)) >= dep[u]) {
            v = fa[v][i];
        }
    }
    if (u == v) return u;
    for (int i = 20; i >= 0; i--) {
        if (fa[u][i] != fa[v][i]) {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[v][0];
}

void update(int u, int v) {
    int x = lca(u, v);
    dis[u]++;
    dis[v]++;
    dis[x] -= 2;
    // cout << x << endl;
}

void query(int x, int fa) {
    if (vis[x]) return;
    vis[x] = 1;
    for (int i = head[x]; ~i; i = e[i].next) {
        int u = e[i].v;
        if (u == fa) {
            continue;
        }
        query(u, x);
        dis[x] += dis[u];
    }
}

int main(void) {
    FAST_IO;
    init();
    int n, m;
    // cin >> n >> m;
    scanf("%d %d", &n, &m);
    for (int i = 1; i < n; i++) {
        int u, v;
        scanf("%d %d", &u, &v);
        add_edge(u, v);
        add_edge(v, u);
    }
    doubly(n);
    for (int i = 0; i < m; i++) {
        int u, v;
        // cin >> u >> v;
        scanf("%d %d", &u, &v);
        update(u, v);
    }
    memset(vis, 0, sizeof(vis));
    // for (int i = 1; i <= n; i++) {
    //     cout << dis[i] << " ";
    // }
    // cout << endl;
    query(1, 1);
    ll ans = 0;
    for (int i = 2; i <= n; i++) {
        if (dis[i] == 0) {
            ans += m;
        }
        if (dis[i] == 1) {
            ans += 1;
        }
    }
    printf("%lld\n", ans);

    return 0;
}
