#include <bits/stdc++.h>
#define FAST_IO std::ios::sync_with_stdio(false),std::cin.tie(0),std::cout.tie(0)

using namespace std;
typedef long long ll;
int const maxn = 100000 + 10;
int vis[maxn], head[maxn];
int fa[maxn][25], dep[maxn], cnt;
int dis[maxn];
int in[maxn];

struct node {
    int v, next;
}e[maxn << 1];

void init() {
    memset(head, -1, sizeof(head));
    memset(dep, 0, sizeof(dep));
    memset(vis, 0, sizeof(vis));
    memset(in, 0, sizeof(in));
    cnt = 0;
}

void add_edge(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

void dfs(int u, int v){
    if (vis[u]) return;
    vis[u] = 1;
    fa[u][0] = v;
    for (int i = head[u]; ~i ; i = e[i].next){
        int x = e[i].v;
        if (v == x) {
            continue;
        }
        dep[x] = dep[u] + 1;
        dfs(x, u);
    }
}

void doubly(int n, int root){
    dfs(root, root);
    for (int j = 1; j <= 20; j++){
        for (int i = 1; i <= n; i++){
            fa[i][j] = fa[fa[i][j - 1]][j - 1];
        }
    }
}

int lca(int u, int v) {
    if (dep[u] > dep[v]) {
        swap(u, v);
    }
    for (int i = 20; i >= 0; i--) {
        if ((dep[v] - (1 << i)) >= dep[u]) {
            v = fa[v][i];
        }
    }
    if (u == v) return u;
    for (int i = 20; i >= 0; i--) {
        if (fa[u][i] != fa[v][i]) {
            u = fa[u][i];
            v = fa[v][i];
        }
    }
    return fa[v][0];
}


int main(void) {

    FAST_IO;
    int t;
    cin >> t;
    string a, b;
    while (t--) {
        int n, m;
        cin >> n >> m;
        int nt = 0, root = 0;
        init();
        map<string, int> mp;
        for (int i = 1; i < n; i++) {
            cin >> a >> b;
            if (mp[a] == 0) {
                mp[a] = ++nt;
            }
            if (mp[b] == 0) {
                mp[b] = ++nt;
            }
            int u = mp[a], v = mp[b];
            add_edge(v, u);
            in[u]++;
        }
        for (int i = 1; i <= n; i++) {
            if (in[i] == 0) {
                root = i;
                break;
            }
        }
        doubly(n, root);
        while (m--) {
            cin >> a >> b;
            int u = mp[a], v = mp[b];
            int f = lca(u, v);
            if (u == v) {
                cout << 0 << endl;
            } else if (f == v) {
                cout << dep[u] - dep[v] << endl;
            } else if (f == u) {
                cout << 1 << endl;
            } else {
                cout << dep[u] - dep[f] + 1 << endl;
            }
        }
    }

    return 0;
}
