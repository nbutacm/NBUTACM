#include <bits/stdc++.h>
using namespace std;
int const maxn = 1e5 + 10;
int inedge[maxn], n, m;
vector<int> e[maxn];

bool toposort(){
    queue<int> q;
    for (int i = 1; i <= n; i++){
        if (!inedge[i])
            q.push(i);
    }
    int cnt = 0;
    while (!q.empty()){
        int v = q.front();
        q.pop();
        cnt++;
        for (int &x : e[v]){
            if(--inedge[x] == 0) q.push(x);
        }
    }
    if (cnt == n) return true;
    return false;
}

void solve(){
    cin >> n >> m;
    memset(e, 0, sizeof(e));    
    memset(inedge, 0, sizeof(inedge));
    for (auto i = 0; i < m; ++i){
        int u, v;
        cin >> u >> v;
        e[u].push_back(v);
        ++inedge[v];
    }
    if (toposort()) cout << "Correct" << endl;
    else cout << "Wrong" << endl;
}

int main(void){

    int t;
    cin >> t;
    while (t--){
        solve();
    }

    return 0;
}
