#include <bits/stdc++.h>

using namespace std;
int const maxn = 1e5 + 10;
int in[maxn];

int main(void) {
    int n, m;
    cin >> n >> m;
    for (int i = 0; i < m; i++) {
        int u, v;
        cin >> u >> v;
        in[u]++;
        in[v]++;
    }
    int one = 0, two = 0, x = 0;
    for (int i = 1; i <= n; i++) {
        if (in[i] == 1) {
            one++;
        } else if (in[i] == 2) {
            two++;
        } else if (in[i] == n - 1) {
            x++;
        }
    }
    if (one == 2 && two == n - 2) {
        cout << "bus topology" << endl;
    } else if (one == n - 1 && x == 1) {
        cout << "star topology" << endl;
    } else if (two == n) {
        cout << "ring topology" <<endl;
    } else {
        cout << "unknown topology" << endl;
    }
    return 0;
}
