#include <bits/stdc++.h>

using namespace std;
typedef long long ll;
int const maxn = 1e5 + 10;

vector<int> e[maxn];
int vis[maxn];

ll v1, v2;

void dfs(int u, int step) {
    if (vis[u]) return;
    vis[u] = 1;
    if (step & 1) {
        v1++;
    } else {
        v2++;
    }
    for (int i = 0; i < e[u].size(); i++) {
        dfs(e[u][i], step + 1);
    }
}

int main(void) {
    int n;
    v1 = v2 = 0;
    cin >> n;
    for (int i = 0; i < n - 1; i++) {
        int u, v;
        cin >> u >> v;
        e[u].push_back(v);
        e[v].push_back(u);
    }
    dfs(1, 1);
    cout << v1 * v2 - (n - 1) << endl;

    return 0;
}
