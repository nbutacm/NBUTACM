#include <bits/stdc++.h>

using namespace std;
int const maxn = 1e5 + 10;
int in[maxn];
int n, m;

int head[maxn], cnt;
vector<int> ans;

struct node {
    int v, next;
} e[maxn << 1];

void add(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}
void init() {
    memset(head, -1, sizeof(head));
    cnt = 0;
}

void toposort() {
    priority_queue<int, vector<int>, greater<int> > q;
    for (int i = 1; i <= n; i++) {
        if (!in[i]) {
            q.push(i);
        }
    } 
    while (!q.empty()) {
        int u = q.top();
        ans.push_back(u);
        q.pop();
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            if (--in[v] == 0) {
                q.push(v);
            }
        }
    }
}

int main(void) {

    while (cin >> n >> m) {
        memset(in, 0, sizeof(in));
        ans.clear();
        init();
        for (int i = 0; i < m; i++) {
            int u, v;
            cin >> u >> v;
            add(u, v);
            in[v]++;
        }
        toposort();
        for (int i = 0; i < ans.size(); i++) {
            if (i == 0) cout << ans[i];
            else cout << " " << ans[i];
        }
        cout << endl;
    }
    
    return 0;
}
