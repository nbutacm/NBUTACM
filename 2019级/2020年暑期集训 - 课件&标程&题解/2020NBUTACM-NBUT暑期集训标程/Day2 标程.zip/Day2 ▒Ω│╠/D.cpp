 #include <bits/stdc++.h>
using namespace std;
#define FAST_IO ios::sync_with_stdio(false),cin.tie(0),cout.tie(0)
int const maxn = 2e5 + 10;
int n, m;
struct node {
    int v, next;
} e[maxn << 1];
int cnt, head[maxn];
int dis[maxn];

void init() {
    cnt = 0;
    memset(head, -1, sizeof(head));
    memset(dis, -1, sizeof(dis));
}

void add(int u, int v) {
    e[cnt].v = v;
    e[cnt].next = head[u];
    head[u] = cnt++;
}

bool bfs(int x) {
    queue<int> q;
    q.emplace(x);
    dis[x] = 0;
    while (!q.empty()) {
        int u = q.front();
        q.pop();
        for (int i = head[u]; ~i; i = e[i].next) {
            int v = e[i].v;
            if (dis[v] == -1) {
                dis[v] = u;
                q.emplace(v);
            }
        }
    }
    for (int i = 2; i <= n; i++) {
        if (dis[i] == -1) {
            return false;
        }
    }
    return true;
}

int main(void) {
    FAST_IO;
    
    cin >> n >> m;    
    init();
    for (int i = 1; i <= m; i++) {
        int u, v;
        cin >> u >> v;
        add(u, v);        
        add(v, u);        
    }

    if (!bfs(1)) {
        cout << "No" << endl;
    } else {
        cout << "Yes" << endl;
        for (int i = 2; i <= n; i++) {
            cout << dis[i] << endl;
        }
    }
    
    return 0;
}

