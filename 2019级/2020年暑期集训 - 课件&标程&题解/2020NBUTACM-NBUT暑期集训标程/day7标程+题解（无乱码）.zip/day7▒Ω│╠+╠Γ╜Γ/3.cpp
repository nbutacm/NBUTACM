//#pragma GCC oplmize(2)    //nlogn�ⷨ
#include <bits/stdc++.h>
#define ll long long
#define sc(x) scanf("%lld",&x)
#define scs(x) scanf("%s",x)
#define pr(x) printf("%lld\n",x)
#define prs(x) printf("%s\n",x)
using namespace std;
const int maxn=1e5+5;
const int mod=998244353;
const double pi=acos(-1.0);
const double eps = 1e-8;
ll t,n,p,q,dp[maxn],s1[maxn],s2[maxn],id[maxn],ans;   //����lcs���������¶���˳���ת��lis����,nlogn���

int main()
{
    ios::sync_with_stdio(false);
    cin.tie(0);
    sc(t);
    for(int k=1;k<=t;k++){
        sc(n),sc(p),sc(q);
        memset(id,0,sizeof(id));
        memset(dp,0,sizeof(dp));
        ans=0;
        for(int i=1;i<=p+1;i++){
            sc(s1[i]);
            id[s1[i]]=i;     //���¶���˳��
        }
        for(int i=1;i<=q+1;i++) sc(s2[i]);
        for(int i=1;i<=q+1;i++){
            if(dp[ans]<id[s2[i]]) dp[++ans]=id[s2[i]];     //�������¶����˳��̰��+�������ڶ������е�lis
            else *lower_bound(dp+1,dp+1+ans,id[s2[i]])=id[s2[i]];
        }
        printf("Case %d: %lld\n",k,ans);
    }
    return 0;
}

// //#pragma GCC optimize(2)    //n^2,tle�ⷨ�������Ż��ռ䣬��ͨ�Ż����ռ䣬��Ϊֻ�õ���2��״̬�����ܹ���2*n�Ŀռ�
// #include <bits/stdc++.h>
// #define ll long long
// #define sc(x) scanf("%lld",&x)
// #define scs(x) scanf("%s",x)
// #define pr(x) printf("%lld\n",x)
// #define prs(x) printf("%s\n",x)
// using namespace std;
// const int maxn=1e5+5;
// const int mod=1e9+7;
// ll t,n,p,q,dp[2][maxn],s1[maxn],s2[maxn];

// int main()
// {
//     ios::sync_with_stdio(false);
//     cin.tie(0);
//     sc(t);
//     for(int k=1;k<=t;k++){
//         sc(n),sc(p),sc(q);
//         memset(dp,0,sizeof(dp));
//         for(int i=1;i<=p+1;i++) sc(s1[i]);
//         for(int i=1;i<=q+1;i++) sc(s2[i]);
//         for(int i=1;i<=p+1;i++)
//             for(int j=1;j<=q+1;j++){
//                 if(s1[i]==s2[j]) dp[i%2][j]=max(dp[i%2][j],dp[(i-1)%2][j-1]+1);
//                 else dp[i%2][j]=max(dp[(i-1)%2][j],dp[i%2][j-1]);
//             }
//         cout<<"Case "<<k<<": "<<max(dp[0][q+1],dp[1][q+1])<<endl;
//     }
//     return 0;
// }

// //#pragma GCC optimize(2)    //n^2,mle�ⷨ����ͨ��lcs
// #include <bits/stdc++.h>
// #define ll long long
// #define sc(x) scanf("%lld",&x)
// #define scs(x) scanf("%s",x)
// #define pr(x) printf("%lld\n",x)
// #define prs(x) printf("%s\n",x)
// using namespace std;
// const int maxn=1e5+5;
// const int mod=1e9+7;
// ll t,n,p,q,dp[maxn][maxn],s1[maxn],s2[maxn];

// int main()
// {
//     ios::sync_with_stdio(false);
//     cin.tie(0);
//     sc(t);
//     for(int k=1;k<=t;k++){
//         sc(n),sc(p),sc(q);
//         memset(dp,0,sizeof(dp));
//         for(int i=1;i<=p+1;i++) sc(s1[i]);
//         for(int i=1;i<=q+1;i++) sc(s2[i]);
//         for(int i=1;i<=p+1;i++)
//             for(int j=1;j<=q+1;j++){
//                 if(s1[i]==s2[j]) dp[i][j]=max(dp[i][j],dp[i-1][j-1]+1);
//                 else dp[i][j]=max(dp[i-1][j],dp[i][j-1]);
//             }
//         cout<<"Case "<<k<<": "<<dp[p+1][q+1]<<endl;
//     }
//     return 0;
// }
