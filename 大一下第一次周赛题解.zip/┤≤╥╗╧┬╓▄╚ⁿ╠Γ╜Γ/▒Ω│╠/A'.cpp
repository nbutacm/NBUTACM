#include <iostream>
#include <cstdio>
#include <cmath>
#include <algorithm>
#include <cstring>
#define ll long long
using namespace std;

int n, k, A, B, num, x;
int a[100005];

int sum(int l, int r){
	int L = lower_bound(a, a + num, l) - a;
	int R = upper_bound(a, a + num, r) - a; 
	R--;
	//cout << L << "  " << R << endl;
	return R - L + 1;
}

ll dfs(int l, int r){
	//printf("%d\n", sum(l, r));
	if(sum(l, r) == 0) {
		//cout << "DFS" << endl << endl;
		return A;
	}
	
	ll tmp = (ll)B * (r - l + 1) * sum(l,r);
	if(l == r) return tmp;
	
	ll L = dfs(l, (l + r)/2);
	
	ll R = dfs((l + r)/2 + 1, r);
	
	if(L + R < tmp) tmp = L + R;
	return tmp;  
}
int main(){
	scanf("%d%d%d%d", &n, &k, &A, &B);
	
	for(int i = 0; i < k; i++){
		scanf("%d", &x);
		a[num++] = x;
	}
	
	sort(a, a+num);
	
	printf("%lld\n", dfs(1, (1 << n)));
	return 0;
}

