#include <bits/stdc++.h>
using namespace std;

string s;
int k;
int a[200];

int main() {
	ios::sync_with_stdio(false);
    int T;
    cin >> T;
    while (T--) {
        memset(a, 0, sizeof a);
        int cnt = 0;
        cin >> s >> k;
        int len(s.size());
        int i = 0, j = 0;
        a[s[0]] = 1;
        cnt++;
        long long ans = 0;
        while (j < len) {
            if(cnt >= k) {
                ans += len - j;
                a[s[i]]--;
                if (a[s[i]] == 0) cnt--;
                i++;
            }
            else {
                j++;
                if (a[s[j]] == 0) cnt++;
                a[s[j]]++;
            }
        }
        cout << ans << endl;
    }
    return 0;
}
