#include <bits/stdc++.h>
using namespace std;
const int N(2e3+5);

int n;
int a[N];

int main() {
    cin >> n;
    int cnt = 0;
    for (int i = 1 ; i <= n; i++) {
        cin >> a[i];
        if(a[i] == 1) cnt++;
    }
    if (cnt) {
        cout << n - cnt << endl;
        return 0;
    }
    int minlen = n + 1, g = 0;
    for (int i = 1; i < n; i++) {
        g = a[i];
        for (int j = i + 1; j <= n; j++) {
            g = __gcd(g, a[j]);
            if(g == 1) {
                minlen = min(minlen, j - i + 1);
                break;
            }
        }
    }
    if(minlen == n+1) cout << -1 << endl;
    else cout << minlen - 1 + n - 1 << endl;
    return 0;
}
