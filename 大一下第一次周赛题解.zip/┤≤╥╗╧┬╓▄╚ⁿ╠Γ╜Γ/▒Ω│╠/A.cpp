#include <bits/stdc++.h>
using namespace std;
const int N(1e5+5);

int n, k;
long long a, b;
int t[N];

long long dfs(int l, int r) {
	int rpos = upper_bound(t + 1, t + k + 1, r) - t;
	int lpos = lower_bound(t + 1, t + k + 1, l) - t;
	int num = rpos - lpos;
	if (num == 0) return a;
	long long res = b * (r - l + 1) * num;
	int mid = (r + l) / 2;
	if (l != r) res = min(res, dfs(l, mid) + dfs(mid + 1, r));
	return res;
}

int main() {
	cin >> n >> k >> a >> b;
	for (int i = 1; i <= k; ++i) cin >> t[i];
	sort(t + 1, t + k + 1);
	cout << dfs(1, 1 << n) << endl;
    return 0;
}
