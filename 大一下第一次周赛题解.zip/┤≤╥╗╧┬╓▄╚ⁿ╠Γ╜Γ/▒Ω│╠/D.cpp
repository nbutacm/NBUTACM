#include <bits/stdc++.h>
using namespace std;
const int N(2e5+5);

int n, s;
int a[N];

int main() {
    cin >> n >> s;
    for (int i = 1; i <= n; i++) cin >> a[i];
    sort(a + 1, a + n + 1);

    long long ans = 0;
    ans += abs(s - a[n / 2 + 1]);
    for (int i = 1; i <= n / 2; i++) {
        if (a[i] > s) ans += a[i] - s;
    }
    for (int i = n / 2 + 2; i <= n; i++) {
        if (a[i] < s) ans += s - a[i];
    }
    cout << ans << endl;
    return 0;
}
